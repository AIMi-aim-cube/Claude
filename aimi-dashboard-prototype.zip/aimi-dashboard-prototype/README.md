# AIMi / FinLLAMA Dashboard Prototype

A clickable MVP prototype for AIMi: education-first AI investment intelligence with Tier 1–5 access, risk onboarding, Ask AIMi, LMS, insights, Tier 4–5 signals, broker hand-off, Tier 5 Quant Intelligence, admin, analytics, and compliance audit logs.

## Quick start
Open `frontend/index.html` in a browser. No build step required.

## Demo accounts
Use the tier selector in the sidebar to switch between Tier 1–5. Features lock/unlock automatically.

## Backend scaffold
`backend/main.py` is a FastAPI scaffold showing the API shape for production.

## Compliance position
AIMi is framed as education, decision intelligence, and broker hand-off only. It does not execute trades, hold funds, provide discretionary portfolio management, or replace human advisory oversight.
