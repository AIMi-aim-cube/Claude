"""
AIMi backend scaffold: FastAPI API layer for production build.
Designed for Firebase Auth, Firestore, GCS, Vertex AI/Gemini, Vector Search, Stripe, broker redirects.
"""
from datetime import datetime, timezone
from enum import IntEnum
from typing import Literal, Optional, List, Dict, Any
from uuid import uuid4

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="AIMi API", version="0.1.0")

class Tier(IntEnum):
    FOUNDATION = 1
    INVESTOR = 2
    PORTFOLIO = 3
    PRO = 4
    ELITE = 5

FEATURES_BY_TIER = {
    1: {"chat": True, "learning": True, "insights": "basic", "signals": False, "quant": False, "advisor": False},
    2: {"chat": True, "learning": True, "insights": "basic", "signals": False, "quant": False, "advisor": False},
    3: {"chat": True, "learning": True, "insights": "portfolio", "signals": False, "quant": False, "advisor": False},
    4: {"chat": True, "learning": True, "insights": "regime", "signals": True, "quant": False, "advisor": False},
    5: {"chat": True, "learning": True, "insights": "full", "signals": True, "quant": True, "advisor": True},
}

class User(BaseModel):
    user_id: str = Field(default_factory=lambda: str(uuid4()))
    email: str
    tier: Tier = Tier.FOUNDATION
    risk_profile: Optional[Literal["Conservative", "Balanced", "Growth-oriented"]] = None
    onboarding_complete: bool = False
    disclosure_version: str = "v1.0"

class ChatRequest(BaseModel):
    user_id: str
    tier: Tier
    prompt: str

class Signal(BaseModel):
    schema_version: str = "signal.v1"
    signal_id: str = Field(default_factory=lambda: str(uuid4()))
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    asset: Dict[str, Any]
    strategy_source: Literal["momentum", "breakout", "mean_reversion", "volatility", "relative_value"]
    regime_state: Literal["RISK_ON", "RISK_OFF", "TRANSITION", "STRESS"]
    direction: Literal["long", "short", "neutral"]
    confidence: int = Field(ge=0, le=100)
    risk_class: Literal["low", "medium", "high"]
    entry_zone: str
    time_horizon: Literal["intraday", "short", "swing", "medium"]
    portfolio_impact: str
    rationale_summary: str
    disclaimer: str = "Informational systematic market intelligence only. Not investment advice. Execution remains user-controlled via external broker."

AUDIT_LOG: List[Dict[str, Any]] = []
USERS: Dict[str, User] = {}

def audit(action: str, actor: str, payload: Dict[str, Any]):
    AUDIT_LOG.append({
        "id": str(uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "actor": actor,
        "action": action,
        "payload": payload,
    })

@app.post("/auth/signup", response_model=User)
def signup(email: str):
    user = User(email=email)
    USERS[user.user_id] = user
    audit("signup", user.user_id, {"tier": int(user.tier)})
    return user

@app.get("/tiers/{tier}/features")
def tier_features(tier: Tier):
    return FEATURES_BY_TIER[int(tier)]

@app.post("/onboarding/risk")
def save_risk_profile(user_id: str, profile: Literal["Conservative", "Balanced", "Growth-oriented"]):
    if user_id not in USERS:
        raise HTTPException(status_code=404, detail="User not found")
    USERS[user_id].risk_profile = profile
    USERS[user_id].onboarding_complete = True
    audit("risk_profile_completed", user_id, {"risk_profile": profile})
    return {"ok": True, "profile": profile}

@app.post("/chat")
def chat(req: ChatRequest):
    text = req.prompt.lower()
    restricted = any(x in text for x in ["what should i buy", "guaranteed", "execute", "trade for me", "portfolio allocation for me"])
    if restricted:
        audit("chat_refusal", req.user_id, {"tier": int(req.tier), "prompt": req.prompt})
        return {"reply": "I can explain concepts, risks, and market context, but I cannot provide personalised investment advice or execute trades. I can show educational scenarios instead.", "restricted": True}
    if req.tier < 4 and any(x in text for x in ["signal", "entry zone", "risk-on", "regime"]):
        return {"reply": "Market regime intelligence and signal explanations are available in higher AIMi tiers. Here is a plain-English overview instead: regimes describe whether markets are broadly supportive, defensive, or unstable.", "upgrade_hint": True}
    return {"reply": "AIMi response placeholder: tier-aware, grounded educational intelligence would be generated here using approved content and audit logging.", "restricted": False}

@app.get("/signals", response_model=List[Signal])
def signals(tier: Tier):
    if tier < 4:
        raise HTTPException(status_code=403, detail="Signals are available to Tier 4–5 only")
    return [
        Signal(asset={"symbol": "SPY", "asset_class": "equity", "exchange": "NYSE Arca"}, strategy_source="momentum", regime_state="RISK_ON", direction="long", confidence=72, risk_class="medium", entry_zone="Above 20-day moving average support", time_horizon="swing", portfolio_impact="Adds broad equity beta exposure", rationale_summary="Momentum, regime alignment, and event context are supportive, with medium risk."),
        Signal(asset={"symbol": "TLT", "asset_class": "rates", "exchange": "NASDAQ"}, strategy_source="relative_value", regime_state="TRANSITION", direction="neutral", confidence=54, risk_class="medium", entry_zone="Wait for confirmation", time_horizon="short", portfolio_impact="Potential duration hedge", rationale_summary="Mixed regime evidence; confidence reduced until volatility stabilises."),
    ]

@app.post("/broker/redirect")
def broker_redirect(user_id: str, broker: str, intent: Literal["buy", "sell", "research"]):
    audit("broker_exit_confirmation", user_id, {"broker": broker, "intent": intent})
    return {"external_url": f"https://broker.example.com/redirect?partner=aimi&intent={intent}", "message": "You are leaving AIMi. Your broker handles execution, confirmation, custody, and suitability."}

@app.get("/admin/audit")
def audit_log():
    return AUDIT_LOG[-100:]
