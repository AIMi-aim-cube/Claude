#!/usr/bin/env bash
# ============================================================================
# AIMi — one-command deploy
#
#   Local / IP-only (HTTP):    ./deploy.sh
#   Production (HTTPS):        ./deploy.sh app.chataimi.ai you@chataimi.ai
#
# Prereqs on the server (Ubuntu 22/24):
#   curl -fsSL https://get.docker.com | sh        # installs docker + compose
#   DNS A-record for your domain -> this server's IP (for HTTPS mode)
#   Ports 80 and 443 open in the firewall / cloud security group
# ============================================================================
set -euo pipefail

DOMAIN="${1:-localhost}"
EMAIL="${2:-}"
cd "$(dirname "$0")"

say()  { printf "\n\033[1;36m▸ %s\033[0m\n" "$*"; }
fail() { printf "\n\033[1;31m✗ %s\033[0m\n" "$*"; exit 1; }

command -v docker >/dev/null || fail "Docker not found. Install: curl -fsSL https://get.docker.com | sh"
docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 not found."

export DOMAIN

# ---------------------------------------------------------------- build app
say "Building AIMi image…"
docker compose build aimi

# ------------------------------------------------- mode 1: HTTP only (demo)
if [[ "$DOMAIN" == "localhost" || -z "$EMAIL" ]]; then
  say "No domain/email given — starting in HTTP mode (fine for demos by IP)."
  say "Note: browser voice input (Web Speech API) requires HTTPS except on localhost."

  # Dummy self-signed cert so the nginx HTTPS block can load without erroring
  docker compose up -d aimi
  docker compose run --rm --entrypoint sh certbot -c "
    mkdir -p /etc/letsencrypt/live/$DOMAIN &&
    apk add --no-cache openssl >/dev/null 2>&1 || true;
    openssl req -x509 -nodes -newkey rsa:2048 -days 365 \
      -keyout /etc/letsencrypt/live/$DOMAIN/privkey.pem \
      -out  /etc/letsencrypt/live/$DOMAIN/fullchain.pem \
      -subj '/CN=$DOMAIN' 2>/dev/null" || true
  docker compose up -d nginx

  IP=$(curl -s --max-time 3 ifconfig.me || hostname -I | awk '{print $1}')
  say "✅ AIMi is live:  http://${IP:-localhost}/   (API docs at /docs)"
  exit 0
fi

# ---------------------------------------------- mode 2: full HTTPS (prod)
say "Deploying for https://$DOMAIN (Let's Encrypt: $EMAIL)"

say "1/4 Bootstrapping temporary self-signed certificate…"
docker compose run --rm --entrypoint sh certbot -c "
  mkdir -p /etc/letsencrypt/live/$DOMAIN &&
  openssl req -x509 -nodes -newkey rsa:2048 -days 1 \
    -keyout /etc/letsencrypt/live/$DOMAIN/privkey.pem \
    -out  /etc/letsencrypt/live/$DOMAIN/fullchain.pem \
    -subj '/CN=$DOMAIN'"

say "2/4 Starting app + nginx…"
docker compose up -d aimi nginx
sleep 3

say "3/4 Requesting real certificate from Let's Encrypt…"
docker compose run --rm certbot certonly --webroot -w /var/www/certbot \
  -d "$DOMAIN" --email "$EMAIL" --agree-tos --no-eff-email --force-renewal \
  || fail "Certbot failed. Check that DNS for $DOMAIN points to this server and port 80 is open."

say "4/4 Reloading nginx with the real certificate…"
docker compose exec nginx nginx -s reload

# Auto-renewal via host cron (idempotent)
CRON_LINE="0 4 * * 1 cd $(pwd) && docker compose run --rm certbot renew --webroot -w /var/www/certbot && docker compose exec nginx nginx -s reload"
( crontab -l 2>/dev/null | grep -vF "certbot renew" ; echo "$CRON_LINE" ) | crontab - || true

say "✅ AIMi is live:  https://$DOMAIN/"
echo  "   • Dashboard:        https://$DOMAIN/"
echo  "   • API docs:         https://$DOMAIN/docs"
echo  "   • Live WebSocket:   wss://$DOMAIN/ws/live"
echo  "   • Funnel analytics: https://$DOMAIN/api/funnel/report"
echo
echo  "   Logs:    docker compose logs -f aimi"
echo  "   Update:  git pull && docker compose build aimi && docker compose up -d aimi"
