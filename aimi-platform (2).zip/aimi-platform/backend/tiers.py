"""
AIMi — Tiers, Entitlements & Billing (SOW 1.4–1.7, 8.5)
=======================================================
Central tier model (1 Foundation → 5 Elite/Advisory) with feature flags,
pricing metadata, upgrade/downgrade rules and Stripe checkout (real Stripe
when STRIPE_SECRET_KEY is set; transparent simulated checkout otherwise so
the full flow is testable end-to-end).

Rules implemented:
  • Upgrades apply immediately, entitlements refresh at once (SOW 1.7)
  • Downgrades & cancellations take effect at the next billing cycle
  • Tier detection on every request via auth.current_user + helpers here
  • Risk-profile completion required before Tier 4–5 intelligence (SOW 1.8)
"""
from __future__ import annotations
import json, os
from fastapi import HTTPException

import db as D

CYCLE_S = 30 * 24 * 3600
STRIPE_KEY = os.getenv("STRIPE_SECRET_KEY", "")


def all_tiers() -> list[dict]:
    with D.db() as con:
        rows = con.execute("SELECT * FROM tier_config ORDER BY tier").fetchall()
    return [{**dict(r), "features": json.loads(r["features"])} for r in rows]


def tier_features(tier: int) -> dict:
    with D.db() as con:
        r = con.execute("SELECT features FROM tier_config WHERE tier=?", (tier,)).fetchone()
    return json.loads(r["features"]) if r else {}


def comparison_for(user_tier: int) -> list[dict]:
    """Tier comparison view: included / newly unlocked / still excluded (SOW 1.6)."""
    tiers = all_tiers()
    cur = tier_features(user_tier)
    out = []
    for t in tiers:
        unlocked = [k for k, v in t["features"].items() if v and not cur.get(k)]
        excluded = []
        if not t["features"].get("signals"):
            excluded.append("Trading signals (Tier 4+)")
        if not t["features"].get("advisory"):
            excluded.append("Human advisory (Tier 5)")
        excluded.append("Trade execution — never provided at any tier")
        out.append({**t, "is_current": t["tier"] == user_tier,
                    "newly_unlocked": unlocked, "still_excluded": excluded,
                    "required_to_invest": False})
    return out


def has_feature(user: dict, feature: str) -> bool:
    return bool(tier_features(user["tier"]).get(feature))


def require_tier(user: dict, min_tier: int, what: str = "this feature"):
    if user["tier"] < min_tier:
        raise HTTPException(403, f"{what} is available from Tier {min_tier}. "
                                 f"You're on Tier {user['tier']} — see /api/tiers/plans to compare.")


def risk_profile_completed(user_id: str) -> bool:
    with D.db() as con:
        r = con.execute("SELECT completed FROM onboarding WHERE user_id=?", (user_id,)).fetchone()
    return bool(r and r["completed"])


def require_risk_profile(user: dict):
    """Tier 4–5: onboarding/risk profiling mandatory before signals (SOW 1.8)."""
    if user["tier"] >= 4 and not risk_profile_completed(user["id"]):
        raise HTTPException(428, "Please complete onboarding & risk profiling first "
                                 "(required before advanced intelligence and signals).")


# ------------------------------------------------------------------ billing
def checkout(user: dict, target_tier: int) -> dict:
    """Start a secure checkout (Stripe if configured, simulated otherwise)."""
    tiers = {t["tier"]: t for t in all_tiers()}
    if target_tier not in tiers:
        raise HTTPException(400, "Unknown tier.")
    if target_tier == user["tier"]:
        raise HTTPException(400, "Already on this tier.")
    price = tiers[target_tier]["price_monthly"]

    if target_tier < user["tier"]:   # downgrade — next billing cycle (SOW 1.7)
        with D.db() as con:
            con.execute("UPDATE users SET pending_tier=?, cycle_ends=COALESCE(cycle_ends, ?) "
                        "WHERE id=?", (target_tier, D.now() + CYCLE_S, user["id"]))
        D.audit(user["id"], "user", "downgrade_scheduled",
                detail={"from": user["tier"], "to": target_tier})
        _bill_event(user["id"], "downgrade", user["tier"], target_tier, 0)
        return {"status": "scheduled", "applies": "next_billing_cycle",
                "message": f"Downgrade to Tier {target_tier} takes effect at your next billing date."}

    if STRIPE_KEY:
        import stripe
        stripe.api_key = STRIPE_KEY
        session = stripe.checkout.Session.create(
            mode="subscription",
            line_items=[{"price_data": {"currency": "usd", "recurring": {"interval": "month"},
                        "unit_amount": int(price * 100),
                        "product_data": {"name": f"AIMi Tier {target_tier} — {tiers[target_tier]['name']}"}},
                        "quantity": 1}],
            success_url=os.getenv("APP_URL", "http://localhost:8000") +
                        f"/api/billing/confirm?u={user['id']}&t={target_tier}&s={{CHECKOUT_SESSION_ID}}",
            cancel_url=os.getenv("APP_URL", "http://localhost:8000") + "/app",
            customer_email=user["email"])
        _bill_event(user["id"], "checkout", user["tier"], target_tier, price, meta=session.id)
        return {"status": "redirect", "checkout_url": session.url}

    # Simulated checkout for dev/demo: confirm immediately
    _bill_event(user["id"], "checkout", user["tier"], target_tier, price, provider="simulated")
    return confirm_payment(user["id"], target_tier, simulated=True)


def confirm_payment(user_id: str, target_tier: int, simulated: bool = False) -> dict:
    """Entitlements update immediately on successful payment (SOW 1.7)."""
    with D.db() as con:
        u = con.execute("SELECT tier FROM users WHERE id=?", (user_id,)).fetchone()
        con.execute("""UPDATE users SET tier=?, billing_status='active',
                       pending_tier=NULL, cycle_ends=? WHERE id=?""",
                    (target_tier, D.now() + CYCLE_S, user_id))
    _bill_event(user_id, "paid", u["tier"], target_tier,
                provider="simulated" if simulated else "stripe")
    D.audit(user_id, "user", "tier_upgraded", detail={"from": u["tier"], "to": target_tier})
    D.notify(user_id, "billing", "Welcome to your new tier",
             f"Tier {target_tier} is now active. Your dashboard has refreshed with new access.")
    return {"status": "active", "tier": target_tier}


def cancel(user: dict) -> dict:
    with D.db() as con:
        con.execute("UPDATE users SET pending_tier=1, billing_status='cancelled' WHERE id=?",
                    (user["id"],))
    _bill_event(user["id"], "cancel", user["tier"], 1)
    D.audit(user["id"], "user", "subscription_cancelled")
    return {"status": "cancelled", "applies": "next_billing_cycle",
            "message": "You keep current access until the end of the billing period."}


def apply_cycle_changes():
    """Background job: apply pending downgrades whose cycle has ended."""
    with D.db() as con:
        rows = con.execute("SELECT id, pending_tier FROM users "
                           "WHERE pending_tier IS NOT NULL AND cycle_ends<=?", (D.now(),)).fetchall()
        for r in rows:
            con.execute("UPDATE users SET tier=?, pending_tier=NULL, cycle_ends=? WHERE id=?",
                        (r["pending_tier"], D.now() + CYCLE_S, r["id"]))
            D.audit(r["id"], "system", "tier_cycle_change", detail={"to": r["pending_tier"]})


def _bill_event(user_id, event, frm, to, amount=0.0, provider="internal", meta=""):
    with D.db() as con:
        con.execute("INSERT INTO billing_events VALUES (?,?,?,?,?,?,?,?,?)",
                    (D.uid(), user_id, event, frm, to, amount, provider, D.now(), meta))
