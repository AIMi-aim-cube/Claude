"""
AIMi — Google Cloud Platform Layer (PGAGI Architecture)
=======================================================
Production implementation uses:
  • Firebase Authentication (identity)
  • Vertex AI Gemini 2.5 Flash (chat, OCR, reasoning)
  • Gemini Embedding 001 (semantic indexing)
  • Vertex AI Vector Search / Matching Engine (RAG memory)
  • Gemini Grounding via Google Search (verified responses)
  • Google Cloud Storage (document storage, AI ingestion)
  • Cloud Firestore (operational memory — users, chat history, tiers)

This module bridges those services. When credentials are absent (dev/demo),
every function raises ImportError-style graceful errors so the platform
falls back to its local equivalents (SQLite, in-memory RAG, hash embedder).

Set these env vars for production:
  GOOGLE_APPLICATION_CREDENTIALS  path to service-account JSON
  GOOGLE_CLOUD_PROJECT             GCP project id
  GCS_BUCKET                       GCS bucket name
  FIREBASE_PROJECT                 Firebase project id (if different)
  VERTEX_LOCATION                  e.g. us-central1
"""
from __future__ import annotations
import os, json

GCP_PROJECT  = os.getenv("GOOGLE_CLOUD_PROJECT", "")
GCS_BUCKET   = os.getenv("GCS_BUCKET", "")
VERTEX_LOC   = os.getenv("VERTEX_LOCATION", "us-central1")
FB_PROJECT   = os.getenv("FIREBASE_PROJECT", GCP_PROJECT)
GEMINI_MODEL = "gemini-2.5-flash"
EMBED_MODEL  = "gemini-embedding-001"


def _require_creds():
    if not GCP_PROJECT or not os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
        raise EnvironmentError(
            "GCP not configured. Set GOOGLE_APPLICATION_CREDENTIALS and "
            "GOOGLE_CLOUD_PROJECT to enable Vertex AI / Firebase. "
            "The platform runs with local fallbacks without them.")


# ----------------------------------------------------------- Firebase Auth
def verify_firebase_token(id_token: str) -> dict:
    """Verify a client-side Firebase ID token (server-side, Admin SDK)."""
    _require_creds()
    import firebase_admin
    from firebase_admin import auth as fb_auth, credentials
    if not firebase_admin._apps:
        cred = credentials.ApplicationDefault()
        firebase_admin.initialize_app(cred, {"projectId": FB_PROJECT})
    decoded = fb_auth.verify_id_token(id_token)
    return {"uid": decoded["uid"], "email": decoded.get("email", ""),
            "provider": decoded.get("firebase", {}).get("sign_in_provider", "unknown")}


# ----------------------------------------------------------- Vertex AI Chat
def gemini_chat(system: str, history: list[dict], user_msg: str) -> str | None:
    """Multi-turn chat via Gemini 2.5 Flash (reasoning + streaming-ready)."""
    _require_creds()
    try:
        import vertexai
        from vertexai.generative_models import GenerativeModel, Content, Part
        vertexai.init(project=GCP_PROJECT, location=VERTEX_LOC)
        model = GenerativeModel(GEMINI_MODEL, system_instruction=system)
        hc = [Content(role=m["role"].replace("assistant", "model"),
                      parts=[Part.from_text(m["content"])]) for m in history[-8:]]
        chat = model.start_chat(history=hc)
        resp = chat.send_message(user_msg)
        return resp.text
    except Exception as exc:
        import logging; logging.getLogger("aimi.gcp").warning("Gemini chat failed: %s", exc)
        return None


# ------------------------------------------------------- Gemini Grounding
def gemini_grounded(query: str) -> dict:
    """Web-grounded response with source citations (Gemini native grounding)."""
    _require_creds()
    import vertexai
    from vertexai.generative_models import GenerativeModel, Tool, grounding
    vertexai.init(project=GCP_PROJECT, location=VERTEX_LOC)
    model = GenerativeModel(GEMINI_MODEL)
    tool = Tool.from_google_search_retrieval(grounding.GoogleSearchRetrieval())
    resp = model.generate_content(query, tools=[tool])
    sources = []
    try:
        for chunk in resp.candidates[0].grounding_metadata.grounding_chunks:
            sources.append({"title": chunk.web.title, "url": chunk.web.uri})
    except Exception:
        pass
    return {"answer": resp.text, "sources": sources}


# ----------------------------------------------------------- Embeddings
def embed_texts(texts: list[str]) -> list[list[float]]:
    """Gemini Embedding 001 — production semantic layer."""
    _require_creds()
    from vertexai.language_models import TextEmbeddingModel
    import vertexai
    vertexai.init(project=GCP_PROJECT, location=VERTEX_LOC)
    model = TextEmbeddingModel.from_pretrained(EMBED_MODEL)
    return [e.values for e in model.get_embeddings(texts)]


# -------------------------------------------- Vertex AI Vector Search
def vector_search(query_embedding: list[float], index_endpoint: str,
                  deployed_index_id: str, k: int = 5) -> list[dict]:
    """Semantic document retrieval via Matching Engine."""
    _require_creds()
    from google.cloud import aiplatform
    aiplatform.init(project=GCP_PROJECT, location=VERTEX_LOC)
    ep = aiplatform.MatchingEngineIndexEndpoint(index_endpoint_name=index_endpoint)
    results = ep.find_neighbors(queries=[query_embedding],
                                num_neighbors=k,
                                deployed_index_id=deployed_index_id)
    return [{"id": n.id, "distance": n.distance} for n in results[0]]


# --------------------------------------------------------- Cloud Storage
def upload_url(destination: str, content_type: str = "application/octet-stream",
               expiry_minutes: int = 15) -> str:
    """Signed upload URL for lesson assets (GCS — production storage per PGAGI arch)."""
    _require_creds()
    from google.cloud import storage
    client = storage.Client(project=GCP_PROJECT)
    bucket = client.bucket(GCS_BUCKET)
    blob = bucket.blob(destination)
    return blob.generate_signed_url(
        version="v4", expiration=expiry_minutes * 60,
        method="PUT", content_type=content_type)


def download_url(path: str, expiry_minutes: int = 60) -> str:
    """Signed read URL for delivering lesson content."""
    _require_creds()
    from google.cloud import storage
    client = storage.Client(project=GCP_PROJECT)
    blob = client.bucket(GCS_BUCKET).blob(path)
    return blob.generate_signed_url(version="v4",
                                    expiration=expiry_minutes * 60, method="GET")


def upload_bytes(data: bytes, destination: str,
                 content_type: str = "application/octet-stream") -> str:
    """Direct upload (server-side, for AI-generated reports)."""
    _require_creds()
    from google.cloud import storage
    client = storage.Client(project=GCP_PROJECT)
    blob = client.bucket(GCS_BUCKET).blob(destination)
    blob.upload_from_string(data, content_type=content_type)
    return f"gs://{GCS_BUCKET}/{destination}"


# --------------------------------------------------------- Firestore sync
def firestore_upsert(collection: str, doc_id: str, data: dict):
    """Mirror structured state to Firestore (users, chat history, tiers, subs)."""
    _require_creds()
    from google.cloud import firestore
    db = firestore.Client(project=GCP_PROJECT)
    db.collection(collection).document(doc_id).set(data, merge=True)


def firestore_get(collection: str, doc_id: str) -> dict | None:
    _require_creds()
    from google.cloud import firestore
    db = firestore.Client(project=GCP_PROJECT)
    doc = db.collection(collection).document(doc_id).get()
    return doc.to_dict() if doc.exists else None
