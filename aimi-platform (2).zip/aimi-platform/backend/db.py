"""
AIMi — Data Layer (SOW Phases 1–8)
==================================
SQLite by default (zero-config); the same repository functions are designed
to be swapped for Cloud Firestore (see gcp.py and PGAGI architecture doc —
production uses Firestore as the unified data layer).

Includes: users/sessions, tier config, subscriptions & billing events,
onboarding & risk profiles, disclosures & acknowledgements (versioned),
conversations/messages/memory, LMS (courses→modules→lessons, progress,
quizzes, badges), insights, signals (lifecycle + approval), broker partners /
links / trade intents / referral events, advisory (intakes, sessions, notes,
follow-ups, messages), admin users & RBAC, notifications, moderation flags,
and a global audit log (SOW 1.11, 8.13).
"""
from __future__ import annotations
import os, json, time, uuid, sqlite3
from contextlib import contextmanager

DB_PATH = os.getenv("AIMI_DB", "data/aimi.db")
if os.path.dirname(DB_PATH):
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)


@contextmanager
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
        con.commit()
    finally:
        con.close()


def now() -> float: return time.time()
def uid() -> str: return uuid.uuid4().hex


SCHEMA = """
-- ============ Phase 1: identity, tiers, billing, onboarding, compliance ===
CREATE TABLE IF NOT EXISTS users(
  id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, pw_hash TEXT,
  auth_provider TEXT DEFAULT 'password',            -- password | firebase
  tier INTEGER DEFAULT 1, status TEXT DEFAULT 'active', -- active|suspended|restricted
  language TEXT DEFAULT 'en', created REAL, last_login REAL,
  billing_status TEXT DEFAULT 'free',               -- free|active|past_due|cancelled
  pending_tier INTEGER, cycle_ends REAL,            -- downgrade applies next cycle
  advisor_id TEXT, notif_prefs TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id TEXT NOT NULL, kind TEXT DEFAULT 'user', -- user|admin
  created REAL, expires REAL
);
CREATE TABLE IF NOT EXISTS tier_config(
  tier INTEGER PRIMARY KEY, name TEXT, price_monthly REAL,
  features TEXT,           -- JSON feature flags (chat_limit_daily, learning, insights...)
  description TEXT, updated REAL
);
CREATE TABLE IF NOT EXISTS billing_events(
  id TEXT PRIMARY KEY, user_id TEXT, event TEXT,    -- checkout|paid|upgrade|downgrade|cancel
  from_tier INTEGER, to_tier INTEGER, amount REAL, provider TEXT, ts REAL, meta TEXT
);
CREATE TABLE IF NOT EXISTS onboarding(
  user_id TEXT PRIMARY KEY, answers TEXT,           -- raw answers JSON
  context TEXT,                                     -- experience/goals/pace (tone control)
  risk_profile TEXT,                                -- conservative|balanced|growth
  completed INTEGER DEFAULT 0, ts REAL
);
CREATE TABLE IF NOT EXISTS disclosures(
  id TEXT PRIMARY KEY, version TEXT, body TEXT, created REAL, active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS acknowledgements(
  id TEXT PRIMARY KEY, user_id TEXT, disclosure_id TEXT, version TEXT, ts REAL
);

-- ============ Phase 2: chatbot ============================================
CREATE TABLE IF NOT EXISTS conversations(
  id TEXT PRIMARY KEY, user_id TEXT, title TEXT, created REAL, updated REAL,
  summary TEXT DEFAULT ''                            -- long-term summarised memory
);
CREATE TABLE IF NOT EXISTS messages(
  id TEXT PRIMARY KEY, conv_id TEXT, role TEXT, content TEXT,
  intent TEXT, refused INTEGER DEFAULT 0, flagged INTEGER DEFAULT 0,
  tier_at_time INTEGER, ts REAL
);
CREATE TABLE IF NOT EXISTS chat_usage(
  user_id TEXT, day TEXT, count INTEGER DEFAULT 0, PRIMARY KEY(user_id, day)
);
CREATE TABLE IF NOT EXISTS rag_sources(
  id TEXT PRIMARY KEY, name TEXT, kind TEXT, min_tier INTEGER DEFAULT 1,
  enabled INTEGER DEFAULT 1, body TEXT, created REAL
);
CREATE TABLE IF NOT EXISTS ai_settings(
  key TEXT PRIMARY KEY, value TEXT                  -- guardrails, rate limits, filters
);

-- ============ Phase 3: LMS ================================================
CREATE TABLE IF NOT EXISTS courses(
  id TEXT PRIMARY KEY, title TEXT, description TEXT, min_tier INTEGER DEFAULT 1,
  language TEXT DEFAULT 'en', difficulty TEXT DEFAULT 'beginner',
  position INTEGER DEFAULT 0, published INTEGER DEFAULT 0, created REAL
);
CREATE TABLE IF NOT EXISTS modules(
  id TEXT PRIMARY KEY, course_id TEXT, title TEXT, position INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS lessons(
  id TEXT PRIMARY KEY, module_id TEXT, title TEXT, kind TEXT,  -- video|pdf|image|quiz|text
  content_url TEXT, body TEXT, duration_s INTEGER DEFAULT 0,
  min_tier INTEGER DEFAULT 1, language TEXT DEFAULT 'en',
  subtitles TEXT DEFAULT '[]', position INTEGER DEFAULT 0,
  published INTEGER DEFAULT 0, version INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS progress(
  user_id TEXT, lesson_id TEXT, completed INTEGER DEFAULT 0,
  resume_pos REAL DEFAULT 0, updated REAL, PRIMARY KEY(user_id, lesson_id)
);
CREATE TABLE IF NOT EXISTS quizzes(
  id TEXT PRIMARY KEY, lesson_id TEXT, questions TEXT,  -- JSON [{q,type,options,answer,explain}]
  required INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS quiz_results(
  id TEXT PRIMARY KEY, user_id TEXT, quiz_id TEXT, score REAL, answers TEXT, ts REAL
);
CREATE TABLE IF NOT EXISTS badges(
  id TEXT PRIMARY KEY, user_id TEXT, kind TEXT, label TEXT, ts REAL
);

-- ============ Phase 4: insights ===========================================
CREATE TABLE IF NOT EXISTS insights(
  id TEXT PRIMARY KEY, kind TEXT,                   -- daily_news|weekly_brief|regime
  title TEXT, body TEXT, summary TEXT, min_tier INTEGER DEFAULT 1,
  status TEXT DEFAULT 'draft',                      -- draft|scheduled|published|expired|retracted
  source TEXT DEFAULT 'ai', sources_meta TEXT DEFAULT '[]',
  publish_at REAL, expires_at REAL, published_at REAL,
  version INTEGER DEFAULT 1, created REAL, created_by TEXT
);

-- ============ Phase 5: signals ============================================
CREATE TABLE IF NOT EXISTS trade_signals(
  id TEXT PRIMARY KEY, asset TEXT, bias TEXT,        -- bullish|bearish|neutral framing
  signal_type TEXT,                                  -- directional|breakout|regime_shift
  horizon TEXT, assumptions TEXT, risk_context TEXT,
  explanation TEXT, invalidation TEXT,
  min_tier INTEGER DEFAULT 4,
  status TEXT DEFAULT 'draft',                       -- draft|pending_approval|active|updated|expired|withdrawn
  origin TEXT DEFAULT 'ai',                          -- ai|human|hybrid
  approved_by TEXT, approved_at REAL,
  created_by TEXT, created REAL, published_at REAL, expires_at REAL,
  version INTEGER DEFAULT 1, update_note TEXT
);
CREATE TABLE IF NOT EXISTS signal_views(
  id TEXT PRIMARY KEY, user_id TEXT, signal_id TEXT, ts REAL
);

-- ============ Phase 6: broker =============================================
CREATE TABLE IF NOT EXISTS broker_partners(
  id TEXT PRIMARY KEY, name TEXT, redirect_template TEXT,  -- e.g. https://b.com/trade?sym={asset}&ref={ref}
  referral_param TEXT DEFAULT 'ref', enabled INTEGER DEFAULT 1, api_key TEXT
);
CREATE TABLE IF NOT EXISTS broker_links(
  user_id TEXT PRIMARY KEY, broker_id TEXT, method TEXT DEFAULT 'manual', ts REAL
);
CREATE TABLE IF NOT EXISTS trade_intents(
  id TEXT PRIMARY KEY, user_id TEXT, signal_id TEXT, asset TEXT, side TEXT,
  tier_at_time INTEGER, confirmed INTEGER DEFAULT 0, redirected INTEGER DEFAULT 0,
  broker_id TEXT, ts REAL
);

-- ============ Phase 7: advisory ===========================================
CREATE TABLE IF NOT EXISTS advisory_intakes(
  id TEXT PRIMARY KEY, user_id TEXT, goals TEXT, constraints_ TEXT,
  horizon TEXT, risk_prefs TEXT, ts REAL
);
CREATE TABLE IF NOT EXISTS advisory_sessions(
  id TEXT PRIMARY KEY, user_id TEXT, advisor_id TEXT, scheduled REAL,
  summary TEXT, advisor_notes TEXT, notes_version INTEGER DEFAULT 1,
  status TEXT DEFAULT 'scheduled', ts REAL
);
CREATE TABLE IF NOT EXISTS followups(
  id TEXT PRIMARY KEY, session_id TEXT, item TEXT, done INTEGER DEFAULT 0, ts REAL
);
CREATE TABLE IF NOT EXISTS private_messages(
  id TEXT PRIMARY KEY, user_id TEXT, sender TEXT, body TEXT, ts REAL
);

-- ============ Phase 8: admin, jobs, moderation, audit =====================
CREATE TABLE IF NOT EXISTS admins(
  id TEXT PRIMARY KEY, email TEXT UNIQUE, pw_hash TEXT,
  role TEXT,                                         -- super_admin|content_admin|signals_admin|advisor
  created REAL, last_login REAL
);
CREATE TABLE IF NOT EXISTS jobs(
  id TEXT PRIMARY KEY, name TEXT, schedule TEXT, enabled INTEGER DEFAULT 1,
  last_run REAL, last_status TEXT, last_error TEXT
);
CREATE TABLE IF NOT EXISTS notifications(
  id TEXT PRIMARY KEY, user_id TEXT, kind TEXT, title TEXT, body TEXT,
  read INTEGER DEFAULT 0, ts REAL
);
CREATE TABLE IF NOT EXISTS moderation_flags(
  id TEXT PRIMARY KEY, kind TEXT, ref_id TEXT, reason TEXT,
  status TEXT DEFAULT 'open', resolved_by TEXT, ts REAL
);
CREATE TABLE IF NOT EXISTS audit_log(
  id TEXT PRIMARY KEY, actor TEXT, actor_kind TEXT,  -- user|admin|system
  action TEXT, target TEXT, detail TEXT, ts REAL
);
"""


def init_db():
    with db() as con:
        con.executescript(SCHEMA)
        # ---- seed tier config (SOW 1.5) ----------------------------------
        if not con.execute("SELECT 1 FROM tier_config").fetchone():
            tiers = [
                (1, "Foundation", 0, {"chat_limit_daily": 10, "memory": False,
                 "learning": True, "insights": "daily_news", "signals": False,
                 "portfolio_logic": False, "advisory": False}),
                (2, "Investor", 19, {"chat_limit_daily": 40, "memory": True,
                 "learning": True, "insights": "daily_news", "signals": False,
                 "portfolio_logic": False, "advisory": False}),
                (3, "Portfolio", 49, {"chat_limit_daily": 100, "memory": True,
                 "learning": True, "insights": "weekly_brief", "signals": False,
                 "portfolio_logic": True, "advisory": False}),
                (4, "AIMi Pro", 99, {"chat_limit_daily": 300, "memory": True,
                 "learning": True, "insights": "regime", "signals": True,
                 "portfolio_logic": True, "advisory": False}),
                (5, "Elite / Advisory", 299, {"chat_limit_daily": 1000, "memory": True,
                 "learning": True, "insights": "regime", "signals": True,
                 "portfolio_logic": True, "advisory": True}),
            ]
            desc = {1: "Plain-English explanations, vocabulary, mental models. No asset or trade discussion.",
                    2: "Conversation memory, investing principles, hypothetical scenarios.",
                    3: "Illustrative allocation logic, diversification, risk/return, macro — educational only.",
                    4: "Market regime insights, volatility & factors, AI patterns, weekly briefings, signals.",
                    5: "Everything in Pro plus human advisory: AIMi handles intake, memory and explanation."}
            for t, name, price, feats in tiers:
                con.execute("INSERT INTO tier_config VALUES (?,?,?,?,?,?)",
                            (t, name, price, json.dumps(feats), desc[t], now()))
        # ---- seed active disclosure (SOW 1.10) ---------------------------
        if not con.execute("SELECT 1 FROM disclosures").fetchone():
            con.execute("INSERT INTO disclosures VALUES (?,?,?,?,1)", (uid(), "v1.0",
                "AIMi is an educational AI guide, not a financial adviser, broker or "
                "robo-trader. AIMi never executes trades, never holds funds, never "
                "manages portfolios, and never provides personalised financial advice. "
                "All investment decisions and executions are yours, via your own broker. "
                "Capital at risk.", now()))
        # ---- seed AI settings (SOW 8.7) -----------------------------------
        for k, v in {"safety_filters": "on", "disclaimers": "on",
                     "upgrade_prompt_cooldown_s": "600",
                     "blocked_terms": json.dumps(["guaranteed returns", "can't lose"])}.items():
            con.execute("INSERT OR IGNORE INTO ai_settings VALUES (?,?)", (k, v))
        # ---- seed default broker partner (SOW 6.1) ------------------------
        if not con.execute("SELECT 1 FROM broker_partners").fetchone():
            con.execute("INSERT INTO broker_partners VALUES (?,?,?,?,1,NULL)",
                        ("demo-broker", "Demo Broker",
                         "https://broker.example.com/trade?symbol={asset}&side={side}&ref={ref}", "ref"))
        # ---- seed scheduled jobs (SOW 4.5 / 8.11) -------------------------
        for jid, name, sched in [("daily_news", "Daily AI finance news", "daily@07:00"),
                                 ("weekly_brief", "Weekly market brief", "weekly@mon07:30"),
                                 ("signal_expiry", "Expire outdated signals", "hourly"),
                                 ("insight_publisher", "Publish scheduled insights", "every60s")]:
            con.execute("INSERT OR IGNORE INTO jobs (id,name,schedule) VALUES (?,?,?)",
                        (jid, name, sched))
        # ---- seed default super admin --------------------------------------
        if not con.execute("SELECT 1 FROM admins").fetchone():
            from auth import hash_pw
            con.execute("INSERT INTO admins VALUES (?,?,?,?,?,NULL)",
                        (uid(), os.getenv("ADMIN_EMAIL", "admin@chataimi.ai"),
                         hash_pw(os.getenv("ADMIN_PASSWORD", "change-me-now")),
                         "super_admin", now()))


# ----------------------------------------------------------- shared helpers
def audit(actor: str, actor_kind: str, action: str, target: str = "", detail: dict | str = ""):
    """Global audit trail (SOW 1.11, 5.8, 7.7, 8.13)."""
    with db() as con:
        con.execute("INSERT INTO audit_log VALUES (?,?,?,?,?,?,?)",
                    (uid(), actor, actor_kind, action, target,
                     json.dumps(detail) if isinstance(detail, dict) else str(detail), now()))


def notify(user_id: str, kind: str, title: str, body: str):
    """Tier/preference-aware notification (SOW 4.9, 5.7, 8.12) with rate limiting."""
    with db() as con:
        u = con.execute("SELECT notif_prefs FROM users WHERE id=?", (user_id,)).fetchone()
        prefs = json.loads(u["notif_prefs"] or "{}") if u else {}
        if prefs.get(kind, True) is False:
            return
        recent = con.execute("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND ts>?",
                             (user_id, now() - 3600)).fetchone()["c"]
        if recent >= 10:   # rate limit: max 10/hour (SOW 5.7)
            return
        con.execute("INSERT INTO notifications VALUES (?,?,?,?,?,0,?)",
                    (uid(), user_id, kind, title, body, now()))
