"""
AIMi — Broker Integration, Redirect-Only (SOW Phase 6)
      + Elite / Advisory Support, Tier 5 (SOW Phase 7)
======================================================
Phase 6: partner config (6.1), non-custodial linking with no credentials
(6.2), trade-intent capture limited to asset+side+signal — quantity, price
and order type are structurally impossible to pass (6.3), mandatory exit
confirmation logged for compliance (6.4), broker-specific redirect URLs with
referral attribution only (6.5/6.6), broker status UI endpoints (6.7).
AIMi never executes, never holds funds, never sees balances or outcomes.

Phase 7: Tier-5 gating (7.1), structured AI intake excluding credentials/
permissions (7.2), advisor-ready editable versioned summaries (7.3), session
continuity with follow-ups (7.4), post-session explanation without new advice
(7.5), private messaging (7.6), full audit (7.7).
"""
from __future__ import annotations
import json
from fastapi import HTTPException

import db as D
import tiers as T


# =========================================================== PHASE 6: BROKER
def list_brokers() -> list[dict]:
    with D.db() as con:
        return [{"id": r["id"], "name": r["name"]}
                for r in con.execute("SELECT * FROM broker_partners WHERE enabled=1")]


def link_broker(user: dict, broker_id: str, method: str = "manual") -> dict:
    """(6.2) Stores connection status ONLY — no credentials, no financial data."""
    with D.db() as con:
        if not con.execute("SELECT 1 FROM broker_partners WHERE id=? AND enabled=1",
                           (broker_id,)).fetchone():
            raise HTTPException(404, "Broker not supported.")
        con.execute("INSERT OR REPLACE INTO broker_links VALUES (?,?,?,?)",
                    (user["id"], broker_id, method, D.now()))
    D.audit(user["id"], "user", "broker_linked", target=broker_id, detail={"method": method})
    return {"linked": broker_id,
            "what_this_enables": "One-click hand-off to your broker when you choose to act.",
            "what_this_does_not_enable": "AIMi cannot place trades, see balances, or manage "
                                         "anything in your broker account."}


def unlink_broker(user: dict) -> dict:
    with D.db() as con:
        con.execute("DELETE FROM broker_links WHERE user_id=?", (user["id"],))
    D.audit(user["id"], "user", "broker_unlinked")
    return {"linked": None}


def broker_status(user: dict) -> dict:
    """(6.7) Linked-broker indicator for profile UI."""
    with D.db() as con:
        l = con.execute("""SELECT b.id, b.name FROM broker_links k
                           JOIN broker_partners b ON b.id=k.broker_id
                           WHERE k.user_id=?""", (user["id"],)).fetchone()
    return {"linked": dict(l) if l else None,
            "guidance": None if l else "Link a broker in your profile to enable one-click "
                                       "hand-off from signals."}


def trade_intent(user: dict, signal_id: str, side: str) -> dict:
    """(6.3) Capture intent: asset + side + signal + tier. Nothing else exists
    in the schema — quantity/price/order-type are excluded by design."""
    T.require_tier(user, 4, "Acting on signals")
    if side not in ("buy", "sell"):
        raise HTTPException(400, "side must be buy or sell")
    with D.db() as con:
        s = con.execute("SELECT * FROM trade_signals WHERE id=? AND status IN ('active','updated')",
                        (signal_id,)).fetchone()
        if not s:
            raise HTTPException(409, "Signal is not active — expired or withdrawn signals "
                                     "cannot be acted on.")
        link = con.execute("SELECT broker_id FROM broker_links WHERE user_id=?",
                           (user["id"],)).fetchone()
        intent_id = D.uid()
        con.execute("""INSERT INTO trade_intents
                       (id,user_id,signal_id,asset,side,tier_at_time,broker_id,ts)
                       VALUES (?,?,?,?,?,?,?,?)""",
                    (intent_id, user["id"], signal_id, s["asset"], side, user["tier"],
                     link["broker_id"] if link else None, D.now()))
    return {"intent_id": intent_id,
            "confirmation_required": True,
            "confirmation_text": ("You are leaving AIMi to place a trade with your broker. "
                                  "AIMi does not execute or manage trades, hold funds, or "
                                  "see your broker account. Continue?")}


def confirm_and_redirect(user: dict, intent_id: str, confirmed: bool) -> dict:
    """(6.4/6.5) Mandatory acknowledgement → logged → broker redirect URL."""
    with D.db() as con:
        it = con.execute("SELECT * FROM trade_intents WHERE id=? AND user_id=?",
                         (intent_id, user["id"])).fetchone()
        if not it:
            raise HTTPException(404, "Intent not found.")
        if not confirmed:
            D.audit(user["id"], "user", "broker_exit_cancelled", target=intent_id)
            return {"redirect_url": None, "message": "Cancelled — you're still in AIMi."}
        broker_id = it["broker_id"]
        if not broker_id:
            b = con.execute("SELECT id FROM broker_partners WHERE enabled=1 LIMIT 1").fetchone()
            if not b:
                raise HTTPException(503, "No broker partners configured.")
            broker_id = b["id"]
        b = con.execute("SELECT * FROM broker_partners WHERE id=?", (broker_id,)).fetchone()
        con.execute("UPDATE trade_intents SET confirmed=1, redirected=1, broker_id=? WHERE id=?",
                    (broker_id, intent_id))
    # (6.5/6.6) non-sensitive params only: asset, side, referral id
    url = b["redirect_template"].format(asset=it["asset"], side=it["side"],
                                        ref=f"aimi-{intent_id[:12]}")
    D.audit(user["id"], "user", "broker_redirect", target=intent_id,
            detail={"broker": broker_id, "asset": it["asset"], "side": it["side"]})
    return {"redirect_url": url, "open_in": "new_tab",
            "note": "Execution, confirmation and outcomes happen entirely at your broker."}


def referral_report() -> dict:
    """(6.6/8.9) Attribution without execution data."""
    with D.db() as con:
        total = con.execute("SELECT COUNT(*) c FROM trade_intents").fetchone()["c"]
        redirected = con.execute("SELECT COUNT(*) c FROM trade_intents WHERE redirected=1").fetchone()["c"]
        by_broker = [dict(r) for r in con.execute(
            """SELECT COALESCE(b.name,'(none)') broker, COUNT(*) clicks
               FROM trade_intents t LEFT JOIN broker_partners b ON b.id=t.broker_id
               WHERE t.redirected=1 GROUP BY t.broker_id""").fetchall()]
        by_signal = [dict(r) for r in con.execute(
            """SELECT s.asset, s.bias, COUNT(*) clicks FROM trade_intents t
               JOIN trade_signals s ON s.id=t.signal_id WHERE t.redirected=1
               GROUP BY t.signal_id ORDER BY clicks DESC LIMIT 10""").fetchall()]
    return {"intents": total, "redirects": redirected,
            "click_through_rate": round(redirected / total * 100, 1) if total else 0,
            "by_broker": by_broker, "top_signals": by_signal,
            "execution_outcomes": "never tracked (non-custodial, redirect-only)"}


# ========================================================= PHASE 7: ADVISORY
EXCLUDED_INTAKE = ("Account credentials, transaction permissions, balances and holdings "
                   "are never collected.")


def _require_elite(user: dict):
    T.require_tier(user, 5, "Advisory support")
    if user["billing_status"] not in ("active", "free"):
        raise HTTPException(402, "An active Tier 5 subscription is required.")


def submit_intake(user: dict, goals: str, constraints: str, horizon: str,
                  risk_prefs: str) -> dict:
    """(7.2) Structured, non-executing intake handled by AIMi."""
    _require_elite(user)
    iid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO advisory_intakes VALUES (?,?,?,?,?,?,?)",
                    (iid, user["id"], goals, constraints, horizon, risk_prefs, D.now()))
    D.audit(user["id"], "user", "advisory_intake", target=iid)
    return {"intake_id": iid, "excluded_data": EXCLUDED_INTAKE,
            "next": "Your advisor will receive an AIMi-prepared summary before your session."}


def advisor_summary(user_id: str) -> dict:
    """(7.3) AI-generated, editable, versioned, clearly preparatory."""
    with D.db() as con:
        intake = con.execute("""SELECT * FROM advisory_intakes WHERE user_id=?
                                ORDER BY ts DESC LIMIT 1""", (user_id,)).fetchone()
        onb = con.execute("SELECT risk_profile FROM onboarding WHERE user_id=?",
                          (user_id,)).fetchone()
        convs = con.execute("""SELECT summary FROM conversations WHERE user_id=?
                               ORDER BY updated DESC LIMIT 3""", (user_id,)).fetchall()
        past = con.execute("""SELECT summary, advisor_notes FROM advisory_sessions
                              WHERE user_id=? AND status='completed'
                              ORDER BY ts DESC LIMIT 2""", (user_id,)).fetchall()
    return {
        "marked_as": "PREPARATORY CONTEXT — not recommendations",
        "risk_profile": onb["risk_profile"] if onb else "not completed",
        "intake": dict(intake) if intake else None,
        "recent_conversation_themes": [c["summary"][-200:] for c in convs if c["summary"]],
        "prior_sessions": [dict(p) for p in past],
    }


def create_session(advisor: dict, user_id: str, scheduled: float) -> dict:
    sid = D.uid()
    summary = json.dumps(advisor_summary(user_id))
    with D.db() as con:
        con.execute("""INSERT INTO advisory_sessions
                       (id,user_id,advisor_id,scheduled,summary,status,ts)
                       VALUES (?,?,?,?,?,'scheduled',?)""",
                    (sid, user_id, advisor["id"], scheduled, summary, D.now()))
    D.audit(advisor["id"], "admin", "advisory_session_created", target=sid,
            detail={"user": user_id})
    return {"session_id": sid}


def save_notes(advisor: dict, session_id: str, notes: str,
               followups: list[str] | None = None) -> dict:
    """(7.3/7.4) Versioned notes + follow-up items; human decisions stay human."""
    with D.db() as con:
        s = con.execute("SELECT * FROM advisory_sessions WHERE id=? AND advisor_id=?",
                        (session_id, advisor["id"])).fetchone()
        if not s:
            raise HTTPException(404, "Session not found or not assigned to you.")
        con.execute("""UPDATE advisory_sessions SET advisor_notes=?,
                       notes_version=notes_version+1, status='completed' WHERE id=?""",
                    (notes, session_id))
        for item in followups or []:
            con.execute("INSERT INTO followups VALUES (?,?,?,0,?)",
                        (D.uid(), session_id, item, D.now()))
    D.audit(advisor["id"], "admin", "advisory_notes_saved", target=session_id,
            detail={"version_bump": True})
    return {"saved": True}


def my_advisory(user: dict) -> dict:
    """(7.4/7.5) Continuity view + post-session reinforcement via AIMi."""
    _require_elite(user)
    with D.db() as con:
        sessions = [dict(r) for r in con.execute(
            """SELECT id, scheduled, status, advisor_notes, notes_version
               FROM advisory_sessions WHERE user_id=? ORDER BY ts DESC""",
            (user["id"],)).fetchall()]
        fups = [dict(r) for r in con.execute(
            """SELECT f.* FROM followups f JOIN advisory_sessions s ON s.id=f.session_id
               WHERE s.user_id=? AND f.done=0""", (user["id"],)).fetchall()]
    for s in sessions:   # AIMi explains, never extends (7.5)
        if s["advisor_notes"]:
            s["aimi_reinforcement"] = ("Your advisor's notes above are the guidance. I can "
                                       "explain any concept they mentioned — I won't add "
                                       "new recommendations of my own.")
    return {"sessions": sessions, "open_followups": fups}


def send_private_message(user: dict | None, advisor: dict | None,
                         target_user_id: str, body: str) -> dict:
    """(7.6) Private, tier-restricted, logged channel."""
    if user:
        _require_elite(user)
        sender, uid_ = "user", user["id"]
    else:
        sender, uid_ = f"advisor:{advisor['id']}", target_user_id
    mid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO private_messages VALUES (?,?,?,?,?)",
                    (mid, uid_, sender, body, D.now()))
    D.audit(user["id"] if user else advisor["id"], "user" if user else "admin",
            "private_message", target=uid_)
    return {"id": mid}


def get_private_messages(user: dict) -> list[dict]:
    _require_elite(user)
    with D.db() as con:
        return [dict(r) for r in con.execute(
            "SELECT sender, body, ts FROM private_messages WHERE user_id=? ORDER BY ts",
            (user["id"],)).fetchall()]
