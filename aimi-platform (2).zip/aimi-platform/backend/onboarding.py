"""
AIMi — Smart Onboarding & Risk Profiling (SOW 1.8, 2.6)
=======================================================
One continuous conversational flow of ~14 plain-English questions.
No financial account data, no asset/portfolio questions, no advice generated.

Internally split into:
  A. Context setup (all tiers): experience, goals, learning pace → tone control
  B. Risk classification: volatility tolerance, time horizon, drawdown
     response → mapped to conservative | balanced | growth (stored)

Optional for Tiers 1–3, required before Tier 4–5 signals/intelligence.
"""
from __future__ import annotations
import json
from fastapi import HTTPException

import db as D

INTRO = ("These questions help me explain markets in a way that fits you. "
         "They don't generate advice or tell you what to invest in.")

QUESTIONS = [
    # ---- A. context (experience / goals / pace) — tone & depth control ----
    {"id": "exp_level",  "group": "context", "q": "How would you describe your investing experience?",
     "options": ["Complete beginner", "Some basics", "Comfortable", "Experienced"]},
    {"id": "exp_topics", "group": "context", "q": "Which topics feel familiar already?",
     "options": ["None yet", "Saving & budgeting", "Funds & ETFs", "Stocks & markets", "Macro & rates"], "multi": True},
    {"id": "goal_main",  "group": "context", "q": "What's the main reason you're here?",
     "options": ["Understand money basics", "Learn to invest long-term", "Understand markets deeper", "Sharpen an existing approach"]},
    {"id": "goal_time",  "group": "context", "q": "How much time can you give to learning each week?",
     "options": ["Under 30 minutes", "About an hour", "A few hours", "As much as it takes"]},
    {"id": "pace",       "group": "context", "q": "How do you like things explained?",
     "options": ["Very simply, step by step", "Simple but quick", "Detailed with examples", "Technical is fine"]},
    {"id": "lang_pref",  "group": "context", "q": "Preferred language for lessons?",
     "options": ["English", "Spanish", "Arabic", "Serbian", "Other"]},
    # ---- B. risk classification (stored, never advice) --------------------
    {"id": "horizon",    "group": "risk", "q": "When might you want to use most of the money you'd invest?",
     "options": ["Within 2 years", "2–5 years", "5–10 years", "10+ years"]},
    {"id": "volatility", "group": "risk", "q": "Imagine your investments moved up and down 15% in a year. How does that feel?",
     "options": ["Very uncomfortable", "Uncomfortable but manageable", "Acceptable", "Completely fine"]},
    {"id": "drawdown",   "group": "risk", "q": "If markets fell 20%, what would you most likely do?",
     "options": ["Sell to stop losses", "Reduce a little", "Hold and wait", "See it as opportunity"]},
    {"id": "income_dep", "group": "risk", "q": "How much would your day-to-day life depend on this money?",
     "options": ["A lot", "Somewhat", "A little", "Not at all"]},
    {"id": "loss_exp",   "group": "risk", "q": "Have you experienced an investment losing value before?",
     "options": ["Never invested", "Yes, and it was stressful", "Yes, handled it fine", "Yes, many times"]},
    {"id": "priority",   "group": "risk", "q": "Which matters more to you right now?",
     "options": ["Protecting what I have", "Steady balance of both", "Growing it over time"]},
    {"id": "sleep",      "group": "risk", "q": "Would market news affect your sleep?",
     "options": ["Definitely", "Sometimes", "Rarely", "Never"]},
    {"id": "consistency","group": "risk", "q": "How consistent is the money you could set aside?",
     "options": ["Irregular", "Mostly regular", "Very regular"]},
]

_RISK_SCORES = {  # option index → points (higher = more growth-oriented)
    "horizon": [0, 1, 2, 3], "volatility": [0, 1, 2, 3], "drawdown": [0, 1, 2, 3],
    "income_dep": [0, 1, 2, 3], "loss_exp": [1, 0, 2, 3], "priority": [0, 1.5, 3],
    "sleep": [0, 1, 2, 3], "consistency": [0, 1.5, 3],
}


def get_flow(user_id: str) -> dict:
    with D.db() as con:
        r = con.execute("SELECT completed FROM onboarding WHERE user_id=?", (user_id,)).fetchone()
    return {"intro": INTRO, "questions": QUESTIONS,
            "completed": bool(r and r["completed"]),
            "notes": ["No financial account data is requested.",
                      "No asset or portfolio discussion.",
                      "Optional for Tiers 1–3; required before Tier 4–5 signals."]}


def submit(user_id: str, answers: dict) -> dict:
    """answers: {question_id: option_index or [indices]}"""
    missing = [q["id"] for q in QUESTIONS if q["id"] not in answers]
    if missing:
        raise HTTPException(400, f"Missing answers: {', '.join(missing)}")

    qmap = {q["id"]: q for q in QUESTIONS}
    context, score, max_score = {}, 0.0, 0.0
    for qid, ans in answers.items():
        q = qmap.get(qid)
        if not q:
            continue
        if q["group"] == "context":
            idxs = ans if isinstance(ans, list) else [ans]
            context[qid] = [q["options"][i] for i in idxs if 0 <= i < len(q["options"])]
        else:
            pts = _RISK_SCORES[qid]
            i = ans if isinstance(ans, int) else ans[0]
            score += pts[min(i, len(pts) - 1)]
            max_score += max(pts)

    ratio = score / max_score if max_score else 0.5
    profile = "conservative" if ratio < 0.40 else "balanced" if ratio < 0.70 else "growth"

    with D.db() as con:
        con.execute("INSERT OR REPLACE INTO onboarding VALUES (?,?,?,?,1,?)",
                    (user_id, json.dumps(answers), json.dumps(context), profile, D.now()))
    D.audit(user_id, "user", "onboarding_completed", detail={"risk_profile": profile})
    return {"completed": True, "risk_profile": profile,
            "context": context,
            "note": "This profile shapes how I explain things — it is not advice."}


def get_profile(user_id: str) -> dict:
    with D.db() as con:
        r = con.execute("SELECT * FROM onboarding WHERE user_id=?", (user_id,)).fetchone()
    if not r:
        return {"completed": False, "risk_profile": None, "context": {}}
    return {"completed": bool(r["completed"]), "risk_profile": r["risk_profile"],
            "context": json.loads(r["context"] or "{}")}


def reset(user_id: str, admin_id: str, reason: str):
    """Admin reset with mandatory reason logging (SOW 8.4, 8.10)."""
    if not reason.strip():
        raise HTTPException(400, "A reason is required to reset onboarding.")
    with D.db() as con:
        con.execute("DELETE FROM onboarding WHERE user_id=?", (user_id,))
    D.audit(admin_id, "admin", "onboarding_reset", target=user_id, detail={"reason": reason})
