"""
AIMi — Insights & Market Intelligence (SOW Phase 4) + Trading Signals (Phase 5)
===============================================================================
Phase 4: data sourcing (scraper), insight schema/states (db), AI generation
pipeline with non-advisory prompt templates and grounding, safety guardrails
(4.4), publish/schedule/expire engine (4.5), tier visibility with locked
previews (4.6), chatbot context integration (4.8), notifications (4.9).

Phase 5: signal governance framework (5.1), AI-assisted creation with
MANDATORY human approval as MVP default (5.2 — answers client query),
explanation & risk-context engine (5.3), versioned lifecycle with expiry
(5.4), strict Tier 4–5 delivery + risk-profile gate (5.5), notifications
(5.7), full compliance logging (5.8). Historical signals remain viewable.
"""
from __future__ import annotations
import json, re
from fastapi import HTTPException

import db as D
import tiers as T
from scraper import news, market_data
from finllama_wrapper import finllama
from signals import signal_generator, DISCLAIMER

INSIGHT_DISCLOSURE = ("This is AI-generated market commentary for education, "
                      "not advice or a recommendation. " + DISCLAIMER)

# ---------------------------------------------------------- safety (4.4)
_ADVISORY_RE = re.compile(r"\byou should (buy|sell)|guaranteed|sure thing|can't lose|"
                          r"\bbuy now\b|\bsell now\b|act immediately", re.I)

def _safety_filter(text: str) -> tuple[str, bool]:
    blocked = bool(_ADVISORY_RE.search(text))
    clean = _ADVISORY_RE.sub("[removed: advisory language]", text)
    return clean, blocked


# ---------------------------------------------------- generation (4.1–4.3)
def generate_daily_news(created_by: str = "system:job") -> dict:
    items = news.fetch_all()[:8]
    if not items:
        raise HTTPException(503, "No market data sources available right now.")
    mood = finllama.aggregate([n.text for n in items])
    lines = [f"• {n.title} — sentiment: {finllama.analyze(n.text).label}" for n in items[:6]]
    body = ("Today's market picture, in plain English.\n\n" + "\n".join(lines) +
            f"\n\nOverall news tone: {mood['label']} ({mood['score']:+.2f}). "
            "These are observations about what is being reported — not instructions.")
    body, blocked = _safety_filter(body)
    sources_meta = [{"source": n.source, "link": n.link, "published": n.published}
                    for n in items[:6]]
    return _create_insight("daily_news", "Daily Finance News", body,
                           f"{len(items)} headlines, tone {mood['label']}",
                           min_tier=1, sources_meta=sources_meta,
                           created_by=created_by, auto_publish=True, blocked=blocked)


def generate_weekly_brief(created_by: str = "system:job") -> dict:
    quotes = market_data.quotes(["SPY", "QQQ", "TSLA", "NVDA"])
    moves = ", ".join(f"{q['ticker']} {q['change_pct']:+.1f}%" for q in quotes)
    mood = finllama.aggregate([n.text for n in news.fetch_all()[:10]])
    body = (f"Weekly market brief.\n\nIndex & mega-cap snapshot: {moves}.\n"
            f"News sentiment across the week leaned {mood['label']}.\n\n"
            "What this means in concept: when breadth and sentiment align, trends tend "
            "to persist; when they diverge, volatility often follows. This brief explains "
            "conditions — it does not suggest actions.")
    body, blocked = _safety_filter(body)
    return _create_insight("weekly_brief", "Weekly Market Brief", body,
                           f"Snapshot: {moves}", min_tier=3,
                           created_by=created_by, auto_publish=True, blocked=blocked)


def generate_regime_commentary(created_by: str = "system:job") -> dict:
    sig = signal_generator.generate("SPY")
    regime = ("risk-on" if sig.composite_score > 0.15 else
              "risk-off" if sig.composite_score < -0.15 else "transitional")
    body = (f"Market regime read: **{regime}**.\n\nComposite of trend, mean-reversion and "
            f"breakout models on broad equities scores {sig.composite_score:+.2f}, with news "
            f"sentiment {sig.sentiment['label']}. In a {regime} regime, historically "
            "volatility behaves differently across asset classes — this is context for "
            "understanding conditions, not a directive.")
    body, blocked = _safety_filter(body)
    return _create_insight("regime", "Market Regime Commentary", body,
                           f"Regime: {regime}", min_tier=4,
                           created_by=created_by, auto_publish=True, blocked=blocked)


def _create_insight(kind, title, body, summary, min_tier, created_by,
                    sources_meta=None, auto_publish=False, blocked=False,
                    publish_at=None, expires_at=None) -> dict:
    iid = D.uid()
    status = "published" if auto_publish and not blocked else \
             "scheduled" if publish_at else "draft"
    with D.db() as con:
        con.execute("""INSERT INTO insights VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)""",
                    (iid, kind, title, body + "\n\n" + INSIGHT_DISCLOSURE, summary,
                     min_tier, status, "ai", json.dumps(sources_meta or []),
                     publish_at, expires_at or D.now() + 7 * 86400,
                     D.now() if status == "published" else None, D.now(), created_by))
        if blocked:
            con.execute("INSERT INTO moderation_flags (id,kind,ref_id,reason,ts) VALUES (?,?,?,?,?)",
                        (D.uid(), "insight_safety", iid, "advisory language blocked", D.now()))
    D.audit(created_by, "system", "insight_generated", target=iid,
            detail={"kind": kind, "blocked": blocked})
    return {"id": iid, "status": status, "safety_blocked": blocked}


# ----------------------------------------------- delivery & tiers (4.6, 4.7)
def list_insights(user: dict) -> list[dict]:
    with D.db() as con:
        rows = con.execute("""SELECT * FROM insights WHERE status='published'
                              ORDER BY published_at DESC LIMIT 30""").fetchall()
    out = []
    for r in rows:
        locked = r["min_tier"] > user["tier"]
        d = {"id": r["id"], "kind": r["kind"], "title": r["title"],
             "summary": r["summary"], "published_at": r["published_at"],
             "min_tier": r["min_tier"], "locked": locked}
        if locked:   # locked preview + soft upgrade (4.6)
            d["body"] = None
            d["lock_message"] = f"Full {r['kind'].replace('_',' ')} unlocks at Tier {r['min_tier']}."
        else:
            d["body"] = r["body"]
        out.append(d)
    return out


def ask_aimi_about(user: dict, insight_id: str, question: str) -> dict:
    """Chatbot context integration (4.8): pass insight into chat, advice-safe."""
    with D.db() as con:
        r = con.execute("SELECT * FROM insights WHERE id=? AND status='published'",
                        (insight_id,)).fetchone()
    if not r:
        raise HTTPException(404, "Insight not found.")
    if r["min_tier"] > user["tier"]:
        raise HTTPException(403, "This insight is above your tier.")
    from chat_engine import chat
    framed = (f"[Context: published AIMi insight '{r['title']}': {r['body'][:600]}] "
              f"User question about this insight: {question}")
    return chat(user, framed)


def run_scheduler_tick():
    """(4.5, 8.11) Publish scheduled insights, expire stale insights & signals."""
    with D.db() as con:
        con.execute("""UPDATE insights SET status='published', published_at=?
                       WHERE status='scheduled' AND publish_at<=?""", (D.now(), D.now()))
        con.execute("""UPDATE insights SET status='expired'
                       WHERE status='published' AND expires_at IS NOT NULL AND expires_at<=?""",
                    (D.now(),))
        con.execute("""UPDATE trade_signals SET status='expired'
                       WHERE status IN ('active','updated') AND expires_at<=?""", (D.now(),))


# ===========================================================================
#                          PHASE 5 — TRADING SIGNALS
# ===========================================================================
PROHIBITED_SIGNAL = re.compile(r"guarantee|risk[- ]free|all[- ]in|put \d+%|position size|"
                               r"buy now|sell now|you must", re.I)

REQUIRED_FIELDS = ["asset", "bias", "signal_type", "horizon", "assumptions", "risk_context"]


def ai_draft_signal(creator: str, ticker: str) -> dict:
    """(5.2) AI-assisted draft from market data + regime models. Always lands in
    pending_approval — human approval is mandatory before publication (MVP default)."""
    s = signal_generator.generate(ticker)
    bias = ("bullish" if "BUY" in s.direction else
            "bearish" if "SELL" in s.direction else "neutral")
    draft = {
        "asset": s.ticker, "bias": bias, "signal_type": "directional",
        "horizon": "2–6 weeks",
        "assumptions": s.rationale,
        "risk_context": (f"Conviction {s.conviction:.0%}. Volatility, news flow, or a macro "
                         f"surprise could reverse this read. Alternative outcome: the move "
                         f"fails and price mean-reverts. Scenario range, not prediction."),
        "explanation": (f"Why this exists: composite of momentum, mean-reversion and breakout "
                        f"models scores {s.composite_score:+.2f}; news sentiment is "
                        f"{s.sentiment['label']}."),
        "invalidation": "A decisive close against the prevailing trend or a sentiment regime "
                        "flip would invalidate this thesis.",
    }
    return create_signal(creator, origin="ai", **draft)


def create_signal(creator: str, origin: str = "human", expires_days: float = 14,
                  **fields) -> dict:
    for f in REQUIRED_FIELDS:
        if not fields.get(f):
            raise HTTPException(400, f"Signal missing mandatory component: {f} (SOW 5.1).")
    blob = " ".join(str(v) for v in fields.values())
    if PROHIBITED_SIGNAL.search(blob):
        raise HTTPException(422, "Signal contains prohibited content "
                                 "(guarantees / sizing / execution language).")
    sid = D.uid()
    with D.db() as con:
        con.execute("""INSERT INTO trade_signals
            (id, asset, bias, signal_type, horizon, assumptions, risk_context,
             explanation, invalidation, min_tier, status, origin, created_by,
             created, expires_at, version)
            VALUES (?,?,?,?,?,?,?,?,?,4,'pending_approval',?,?,?,?,1)""",
            (sid, fields["asset"].upper(), fields["bias"], fields["signal_type"],
             fields["horizon"], fields["assumptions"], fields["risk_context"],
             fields.get("explanation", ""), fields.get("invalidation", ""),
             origin, creator, D.now(), D.now() + expires_days * 86400))
    D.audit(creator, "admin" if origin != "ai" else "system", "signal_drafted",
            target=sid, detail={"origin": origin, "asset": fields["asset"]})
    return {"id": sid, "status": "pending_approval",
            "note": "Human approval required before publication."}


def approve_signal(admin: dict, signal_id: str) -> dict:
    """(5.2/5.8) Final approver is a Signals Admin; approval fully logged."""
    with D.db() as con:
        s = con.execute("SELECT * FROM trade_signals WHERE id=?", (signal_id,)).fetchone()
        if not s:
            raise HTTPException(404, "Signal not found.")
        if s["status"] != "pending_approval":
            raise HTTPException(409, f"Signal is {s['status']}, not pending approval.")
        origin = "hybrid" if s["origin"] == "ai" else s["origin"]
        con.execute("""UPDATE trade_signals SET status='active', approved_by=?,
                       approved_at=?, published_at=?, origin=? WHERE id=?""",
                    (admin["id"], D.now(), D.now(), origin, signal_id))
        eligible = con.execute("SELECT id FROM users WHERE tier>=4 AND status='active'").fetchall()
    D.audit(admin["id"], "admin", "signal_approved", target=signal_id)
    for u in eligible:   # (5.7) tier-eligible notifications, rate-limited in db.notify
        D.notify(u["id"], "signal", "New signal published",
                 f"{s['asset']}: {s['bias']} ({s['horizon']}). Open Signals to read the "
                 "explanation and risk context.")
    return {"id": signal_id, "status": "active"}


def update_signal(admin: dict, signal_id: str, update_note: str, **changes) -> dict:
    with D.db() as con:
        s = con.execute("SELECT * FROM trade_signals WHERE id=?", (signal_id,)).fetchone()
        if not s:
            raise HTTPException(404, "Signal not found.")
        sets, vals = ["status='updated'", "version=version+1", "update_note=?"], [update_note]
        for k in ("risk_context", "explanation", "horizon", "expires_at"):
            if k in changes:
                sets.append(f"{k}=?"); vals.append(changes[k])
        con.execute(f"UPDATE trade_signals SET {', '.join(sets)} WHERE id=?", (*vals, signal_id))
    D.audit(admin["id"], "admin", "signal_updated", target=signal_id, detail={"note": update_note})
    return {"id": signal_id, "status": "updated"}


def withdraw_signal(admin: dict, signal_id: str, reason: str) -> dict:
    with D.db() as con:
        con.execute("UPDATE trade_signals SET status='withdrawn', update_note=? WHERE id=?",
                    (reason, signal_id))
    D.audit(admin["id"], "admin", "signal_withdrawn", target=signal_id, detail={"reason": reason})
    return {"id": signal_id, "status": "withdrawn"}


def list_signals_for_user(user: dict, include_history: bool = True) -> list[dict]:
    """(5.5) Backend tier enforcement: Tier 1–3 see nothing but a locked notice."""
    if user["tier"] < 4:
        return [{"locked": True,
                 "lock_message": "Trading signals are part of AIMi Pro (Tier 4) and Elite "
                                 "(Tier 5). Signals are explained market intelligence — "
                                 "never instructions."}]
    T.require_risk_profile(user)            # risk profiling mandatory (1.8/5.5)
    statuses = ("active", "updated", "expired", "withdrawn") if include_history \
               else ("active", "updated")
    with D.db() as con:
        rows = con.execute(f"""SELECT * FROM trade_signals
                               WHERE status IN ({','.join('?'*len(statuses))})
                               ORDER BY published_at DESC LIMIT 50""", statuses).fetchall()
        for r in rows:
            con.execute("INSERT INTO signal_views VALUES (?,?,?,?)",
                        (D.uid(), user["id"], r["id"], D.now()))
    out = []
    for r in rows:
        d = dict(r)
        d["interactive"] = r["status"] in ("active", "updated")  # expired = read-only (5.4)
        d["disclaimer"] = ("Market intelligence, not a recommendation. Execution happens "
                           "only at your broker. " + DISCLAIMER)
        out.append(d)
    return out
