"""
AIMi — Main API (SOW Phases 1–8, complete)
==========================================
Run:  uvicorn main:app --reload --port 8000
Docs: http://localhost:8000/docs
"""
from __future__ import annotations
import asyncio, json
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, Form, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

import db as D
D.init_db()

import auth, tiers as T, onboarding as ONB, chat_engine, lms
import insights_signals as IS, broker_advisory as BA
from scraper import market_data, news
from finllama_wrapper import finllama
from signals import signal_generator
from rag_pipeline import rag
from voice import voice_chat
from funnel import funnel
import admin_portal

lms.seed_demo_content()

app = FastAPI(title="AIMi API", version="1.0.0",
              description="AI-powered financial intelligence — chataimi.ai (SOW v1, Phases 1–8)")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])
app.include_router(admin_portal.router)

User = Depends(auth.current_user)
DEFAULT_WATCHLIST = ["AAPL","MSFT","NVDA","SPY","TSLA"]

# ============================================================= Phase 1
class SignupBody(BaseModel): email: str; password: str
@app.post("/api/auth/signup", tags=["1-Auth"])
def signup(b: SignupBody): return auth.signup(b.email, b.password)

class LoginBody(BaseModel): email: str; password: str
@app.post("/api/auth/login", tags=["1-Auth"])
def login(b: LoginBody): return auth.login(b.email, b.password)

class FBLogin(BaseModel): id_token: str
@app.post("/api/auth/firebase", tags=["1-Auth"])
def firebase(b: FBLogin): return auth.firebase_login(b.id_token)

@app.post("/api/auth/logout", tags=["1-Auth"])
def logout(authorization: str = "", user=User):
    auth.destroy_session(authorization.removeprefix("Bearer ").strip())
    return {"ok": True}

@app.get("/api/me", tags=["1-Profile"])
def me(user=User):
    with D.db() as con:
        u = con.execute("SELECT id,email,tier,status,language,billing_status,advisor_id FROM users WHERE id=?", (user["id"],)).fetchone()
    return dict(u)

@app.get("/api/tiers/plans", tags=["1-Tiers"])
def plans(user=User): return T.comparison_for(user["tier"])

@app.post("/api/billing/checkout/{tier}", tags=["1-Billing"])
def checkout(tier: int, user=User): return T.checkout(user, tier)

@app.get("/api/billing/confirm", tags=["1-Billing"])
def confirm_payment(u: str, t: int, s: str = ""): return T.confirm_payment(u, int(t))

@app.post("/api/billing/cancel", tags=["1-Billing"])
def cancel(user=User): return T.cancel(user)

@app.get("/api/onboarding/flow", tags=["1-Onboarding"])
def onb_flow(user=User): return ONB.get_flow(user["id"])

class OnbSubmit(BaseModel): answers: dict
@app.post("/api/onboarding/submit", tags=["1-Onboarding"])
def onb_submit(b: OnbSubmit, user=User): return ONB.submit(user["id"], b.answers)

@app.get("/api/onboarding/profile", tags=["1-Onboarding"])
def onb_profile(user=User): return ONB.get_profile(user["id"])

@app.get("/api/disclosures/active", tags=["1-Compliance"])
def disclosures():
    with D.db() as con:
        r = con.execute("SELECT * FROM disclosures WHERE active=1 LIMIT 1").fetchone()
    return dict(r) if r else {}

class Ack(BaseModel): disclosure_id: str; version: str
@app.post("/api/disclosures/acknowledge", tags=["1-Compliance"])
def acknowledge(b: Ack, user=User):
    with D.db() as con:
        con.execute("INSERT INTO acknowledgements VALUES (?,?,?,?,?)",
                    (D.uid(), user["id"], b.disclosure_id, b.version, D.now()))
    D.audit(user["id"], "user", "disclosure_acknowledged", detail={"version": b.version})
    return {"ok": True}

@app.get("/api/dashboard", tags=["1-Dashboard"])
def dashboard_shell(user=User):
    feats = T.tier_features(user["tier"])
    return {"tier": user["tier"], "features": feats,
            "sections": ["learn","ask_aimi","insights"],
            "has_signals": feats.get("signals", False),
            "has_advisory": feats.get("advisory", False)}

# ============================================================= Phase 2
class ChatReq(BaseModel): message: str; conv_id: str | None = None; history: list = []
@app.post("/api/chat", tags=["2-Chatbot"])
def chat(b: ChatReq, user=User):
    funnel.track(user["id"], "chat_message")
    return chat_engine.chat(user, b.message, b.conv_id)

@app.get("/api/chat/conversations", tags=["2-Chatbot"])
def conversations(user=User):
    with D.db() as con:
        rows = con.execute("SELECT id,title,created,updated FROM conversations WHERE user_id=? ORDER BY updated DESC LIMIT 30", (user["id"],)).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/chat/conversations/{conv_id}", tags=["2-Chatbot"])
def conversation(conv_id: str, user=User):
    with D.db() as con:
        c = con.execute("SELECT * FROM conversations WHERE id=? AND user_id=?", (conv_id, user["id"])).fetchone()
        if not c: return {"error": "Not found"}
        msgs = [dict(r) for r in con.execute("SELECT role,content,intent,refused,ts FROM messages WHERE conv_id=? ORDER BY ts", (conv_id,)).fetchall()]
    return {**dict(c), "messages": msgs}

@app.post("/api/voice", tags=["2-Voice"])
async def voice(text: str | None = Form(None), audio: UploadFile | None = File(None), user=User):
    funnel.track(user["id"], "voice_used")
    ab = await audio.read() if audio else None
    return voice_chat(text=text, audio_bytes=ab, filename=audio.filename if audio else "audio.webm")

# ============================================================= Phase 3
@app.get("/api/learn/library", tags=["3-LMS"])
def library(user=User, topic: str | None = None, language: str | None = None, difficulty: str | None = None):
    return lms.library(user, topic, language, difficulty)

@app.get("/api/learn/lessons/{lesson_id}", tags=["3-LMS"])
def lesson(lesson_id: str, user=User):
    funnel.track(user["id"], "lesson_viewed")
    return lms.get_lesson(user, lesson_id)

class ProgressBody(BaseModel): resume_pos: float = 0; completed: bool = False
@app.post("/api/learn/lessons/{lesson_id}/progress", tags=["3-LMS"])
def progress(lesson_id: str, b: ProgressBody, user=User):
    return lms.update_progress(user, lesson_id, b.resume_pos, b.completed)

@app.get("/api/learn/quiz/{quiz_id}", tags=["3-LMS"])
def get_quiz(quiz_id: str, user=User): return lms.get_quiz(user, quiz_id)

class QuizSubmit(BaseModel): answers: list
@app.post("/api/learn/quiz/{quiz_id}/submit", tags=["3-LMS"])
def submit_quiz(quiz_id: str, b: QuizSubmit, user=User): return lms.submit_quiz(user, quiz_id, b.answers)

@app.get("/api/learn/badges", tags=["3-LMS"])
def badges(user=User): return lms.my_badges(user["id"])

@app.get("/api/learn/recommend", tags=["3-LMS"])
def recommend(user=User, context: str = ""): return lms.recommend(user, context)

# ============================================================= Phase 4
@app.get("/api/insights", tags=["4-Insights"])
def insights(user=User):
    funnel.track(user["id"], "insights_viewed")
    return IS.list_insights(user)

class AskAbout(BaseModel): question: str
@app.post("/api/insights/{insight_id}/ask", tags=["4-Insights"])
def ask_about(insight_id: str, b: AskAbout, user=User):
    return IS.ask_aimi_about(user, insight_id, b.question)

# ============================================================= Phase 5
@app.get("/api/signals", tags=["5-Signals"])
def signals(user=User, history: bool = True):
    funnel.track(user["id"], "signal_viewed")
    return IS.list_signals_for_user(user, include_history=history)

# ============================================================= Phase 6
@app.get("/api/broker/list", tags=["6-Broker"])
def broker_list(): return BA.list_brokers()

class LinkBroker(BaseModel): broker_id: str; method: str = "manual"
@app.post("/api/broker/link", tags=["6-Broker"])
def link(b: LinkBroker, user=User): return BA.link_broker(user, b.broker_id, b.method)

@app.delete("/api/broker/link", tags=["6-Broker"])
def unlink(user=User): return BA.unlink_broker(user)

@app.get("/api/broker/status", tags=["6-Broker"])
def broker_status(user=User): return BA.broker_status(user)

class IntentBody(BaseModel): signal_id: str; side: str
@app.post("/api/broker/intent", tags=["6-Broker"])
def intent(b: IntentBody, user=User): return BA.trade_intent(user, b.signal_id, b.side)

class ConfirmBody(BaseModel): intent_id: str; confirmed: bool
@app.post("/api/broker/redirect", tags=["6-Broker"])
def redirect_broker(b: ConfirmBody, user=User): return BA.confirm_and_redirect(user, b.intent_id, b.confirmed)

# ============================================================= Phase 7
class IntakeBody(BaseModel): goals: str; constraints: str; horizon: str; risk_prefs: str
@app.post("/api/advisory/intake", tags=["7-Advisory"])
def intake(b: IntakeBody, user=User): return BA.submit_intake(user, **b.model_dump())

@app.get("/api/advisory/sessions", tags=["7-Advisory"])
def adv_sessions(user=User): return BA.my_advisory(user)

class MsgBody(BaseModel): body: str
@app.post("/api/advisory/messages", tags=["7-Advisory"])
def private_msg(b: MsgBody, user=User): return BA.send_private_message(user, None, user["id"], b.body)

@app.get("/api/advisory/messages", tags=["7-Advisory"])
def get_msgs(user=User): return BA.get_private_messages(user)

# ============================================================= Funnel
class TrackBody(BaseModel): event: str; props: dict = {}; source: str | None = None
@app.post("/api/funnel/track", tags=["Funnel"])
def track(b: TrackBody, user=User): return funnel.track(user["id"], b.event, b.props, b.source)

@app.get("/api/funnel/report", tags=["Funnel"])
def funnel_report(hours: float = 720, admin=Depends(auth.current_admin)):
    return funnel.funnel_report(hours)

# ============================================================= Market data (unauthenticated for dashboard)
@app.get("/api/quote/{ticker}", tags=["Market"])
def quote(ticker: str): return market_data.quote(ticker)

@app.get("/api/history/{ticker}", tags=["Market"])
def history(ticker: str, period: str = "6mo"):
    df = market_data.history(ticker, period)
    return {"ticker": ticker.upper(),
            "bars": [{"t": str(i.date()), "o": round(r.open,2), "h": round(r.high,2),
                      "l": round(r.low,2), "c": round(r.close,2), "v": int(r.volume)}
                     for i, r in df.iterrows()]}

@app.get("/api/news", tags=["Market"])
def get_news(ticker: str | None = None):
    items = news.for_ticker(ticker) if ticker else news.fetch_all()[:12]
    return [{"title": n.title, "summary": n.summary, "link": n.link,
             "source": n.source, "published": n.published,
             "sentiment": finllama.analyze(n.text).to_dict()} for n in items]

# ============================================================= WebSocket
@app.websocket("/ws/live")
async def live(ws: WebSocket):
    await ws.accept()
    watchlist = DEFAULT_WATCHLIST[:]
    tick = 0
    try:
        async def reader():
            nonlocal watchlist
            while True:
                try:
                    d = json.loads(await ws.receive_text())
                    if isinstance(d.get("watchlist"), list):
                        watchlist = [t.upper() for t in d["watchlist"]][:10] or watchlist
                except Exception:
                    pass
        rt = asyncio.create_task(reader())
        while True:
            quotes = await asyncio.to_thread(market_data.quotes, watchlist)
            payload = {"type": "quotes", "data": quotes}
            if tick % 6 == 0:
                t = watchlist[tick // 6 % len(watchlist)]
                sig = await asyncio.to_thread(signal_generator.generate, t)
                payload["signal"] = sig.to_dict()
            await ws.send_json(payload)
            tick += 1
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        pass
    finally:
        rt.cancel()

# ============================================================= Frontend
@app.get("/", include_in_schema=False)
def root(): return FileResponse("../frontend/dashboard.html")

@app.get("/app", include_in_schema=False)
def app_ui(): return FileResponse("../frontend/app.html")
