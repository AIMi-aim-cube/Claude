"""
AIMi — Admin Portal (SOW Phase 8, complete)
==========================================
8.1  Isolated admin portal with separate auth (auth.admin_login)
8.2  RBAC: super_admin | content_admin | signals_admin | advisor
8.3  Operational dashboard: users by tier, chat usage, signals CTR,
     learning completion, system alerts
8.4  User management: view/suspend/reset-onboarding/assign-advisor
8.5  Tier & feature configuration
8.6  Learning content management (course/module/lesson/quiz CRUD,
     preview-as-tier, publish/unpublish) → delegates to lms.py
8.7  AI knowledge & chatbot controls: RAG sources, guardrails,
     rate limits, simulate-as-tier, review flagged conversations
8.8  Insights & signals admin console (full lifecycle)
8.9  Broker integration & referral tracking
8.10 Risk profile oversight (view distributions, re-trigger, audit)
8.11 Automation & scheduling controls
8.12 Notifications & communication management
8.13 Moderation, logs & compliance (export, flag review, audit)
8.14 Analytics & reporting (growth, retention, cohort, upgrade funnels)
"""
from __future__ import annotations
import json, csv, io, time
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import db as D
import auth
import tiers as T
import onboarding as ONB
import lms
import insights_signals as IS
import broker_advisory as BA
from funnel import funnel

router = APIRouter(prefix="/api/admin", tags=["admin"])
SA   = Depends(auth.require_role("super_admin"))
CA   = Depends(auth.require_role("super_admin", "content_admin"))
SIGA = Depends(auth.require_role("super_admin", "signals_admin"))
ADV  = Depends(auth.require_role("advisor"))

# ============================================================ 8.1 AUTH
class AdminCreds(BaseModel):
    email: str; password: str

@router.post("/login")
def admin_login(body: AdminCreds):
    return auth.admin_login(body.email, body.password)

@router.post("/logout")
def admin_logout(authorization: str = "", admin=Depends(auth.current_admin)):
    token = authorization.removeprefix("Bearer ").strip()
    auth.destroy_session(token)
    D.audit(admin["id"], "admin", "admin_logout")
    return {"ok": True}

# ============================================================ 8.3 DASHBOARD
@router.get("/dashboard", dependencies=[SA])
def dashboard():
    with D.db() as con:
        by_tier = {r["tier"]: r["n"] for r in con.execute(
            "SELECT tier, COUNT(*) n FROM users GROUP BY tier").fetchall()}
        chat_today = {r["tier"]: r["msgs"] for r in con.execute("""
            SELECT u.tier, COUNT(*) msgs FROM messages m
            JOIN conversations c ON c.id=m.conv_id
            JOIN users u ON u.id=c.user_id
            WHERE m.ts > ? GROUP BY u.tier""", (D.now()-86400,)).fetchall()}
        signal_ctr = con.execute(
            "SELECT COUNT(*) c FROM trade_intents WHERE redirected=1 AND ts>?",
            (D.now()-86400,)).fetchone()["c"]
        learn_rate = lms.learning_analytics()["completion_rate"]
        alerts = [dict(r) for r in con.execute(
            "SELECT * FROM moderation_flags WHERE status='open' ORDER BY ts DESC LIMIT 10"
        ).fetchall()]
        failed_jobs = [dict(r) for r in con.execute(
            "SELECT * FROM jobs WHERE last_status='error'").fetchall()]
    return {"active_users_by_tier": by_tier, "chat_messages_today_by_tier": chat_today,
            "signal_broker_clicks_24h": signal_ctr, "learning_completion_rate_pct": learn_rate,
            "open_alerts": alerts, "failed_jobs": failed_jobs}

# ============================================================ 8.4 USER MGMT
@router.get("/users", dependencies=[SA])
def list_users(page: int = 0, limit: int = 50, tier: int | None = None):
    with D.db() as con:
        q = "SELECT id,email,tier,status,billing_status,created,last_login,advisor_id " \
            "FROM users" + (f" WHERE tier={tier}" if tier else "") + \
            f" ORDER BY created DESC LIMIT {limit} OFFSET {page*limit}"
        rows = [dict(r) for r in con.execute(q).fetchall()]
    return {"users": rows, "page": page}

@router.get("/users/{uid}", dependencies=[SA])
def get_user(uid: str):
    with D.db() as con:
        u = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not u: raise HTTPException(404, "User not found.")
        onb = con.execute("SELECT risk_profile,completed FROM onboarding WHERE user_id=?",
                          (uid,)).fetchone()
        billing = [dict(r) for r in con.execute(
            "SELECT * FROM billing_events WHERE user_id=? ORDER BY ts DESC LIMIT 10",
            (uid,)).fetchall()]
    return {**dict(u), "onboarding": dict(onb) if onb else None, "billing_history": billing}

class SuspendBody(BaseModel):
    action: str; reason: str  # suspend | restrict | reactivate

@router.post("/users/{uid}/status", dependencies=[SA])
def set_user_status(uid: str, body: SuspendBody, admin=SA):
    if body.action not in ("suspend", "restrict", "reactivate"):
        raise HTTPException(400, "action must be suspend|restrict|reactivate")
    status = {"suspend": "suspended", "restrict": "restricted", "reactivate": "active"}[body.action]
    with D.db() as con:
        con.execute("UPDATE users SET status=? WHERE id=?", (status, uid))
    D.audit(admin["id"], "admin", f"user_{body.action}", target=uid, detail={"reason": body.reason})
    return {"uid": uid, "status": status}

class ResetOnb(BaseModel):
    reason: str

@router.post("/users/{uid}/reset-onboarding", dependencies=[SA])
def reset_onboarding(uid: str, body: ResetOnb, admin=SA):
    ONB.reset(uid, admin["id"], body.reason)
    return {"ok": True}

class AssignAdvisor(BaseModel):
    advisor_id: str

@router.post("/users/{uid}/assign-advisor", dependencies=[SA])
def assign_advisor(uid: str, body: AssignAdvisor, admin=SA):
    with D.db() as con:
        adv = con.execute("SELECT id FROM admins WHERE id=? AND role='advisor'",
                          (body.advisor_id,)).fetchone()
        if not adv: raise HTTPException(404, "Advisor not found.")
        con.execute("UPDATE users SET advisor_id=? WHERE id=?", (body.advisor_id, uid))
    D.audit(admin["id"], "admin", "advisor_assigned", target=uid,
            detail={"advisor": body.advisor_id})
    return {"ok": True}

# ============================================================ 8.5 TIERS
@router.get("/tiers", dependencies=[SA])
def get_tiers(): return T.all_tiers()

class TierUpdate(BaseModel):
    name: str | None = None
    price_monthly: float | None = None
    features: dict | None = None
    description: str | None = None

@router.patch("/tiers/{tier}", dependencies=[SA])
def update_tier(tier: int, body: TierUpdate, admin=SA):
    with D.db() as con:
        row = con.execute("SELECT * FROM tier_config WHERE tier=?", (tier,)).fetchone()
        if not row: raise HTTPException(404, "Tier not found.")
        feats = json.loads(row["features"])
        if body.features: feats.update(body.features)
        con.execute("""UPDATE tier_config SET name=COALESCE(?,name),
                       price_monthly=COALESCE(?,price_monthly),
                       features=?, description=COALESCE(?,description), updated=?
                       WHERE tier=?""",
                    (body.name, body.price_monthly, json.dumps(feats),
                     body.description, D.now(), tier))
    D.audit(admin["id"], "admin", "tier_config_updated", target=str(tier),
            detail=body.model_dump(exclude_none=True))
    return {"ok": True}

# ============================================================ 8.6 CONTENT
class CourseBody(BaseModel):
    title: str; description: str; min_tier: int = 1
    language: str = "en"; difficulty: str = "beginner"

@router.post("/courses", dependencies=[CA])
def create_course(body: CourseBody, admin=CA):
    return lms.admin_create_course(admin, **body.model_dump())

class ModuleBody(BaseModel):
    course_id: str; title: str; position: int = 0

@router.post("/modules", dependencies=[CA])
def create_module(body: ModuleBody, admin=CA):
    return lms.admin_create_module(admin, **body.model_dump())

class LessonBody(BaseModel):
    module_id: str; title: str; kind: str
    content_url: str = ""; body: str = ""; min_tier: int = 1
    language: str = "en"; duration_s: int = 0; position: int = 0
    subtitles: list = []

@router.post("/lessons", dependencies=[CA])
def create_lesson(body: LessonBody, admin=CA):
    return lms.admin_create_lesson(admin, **body.model_dump())

class PublishBody(BaseModel):
    kind: str; item_id: str; published: bool

@router.post("/content/publish", dependencies=[CA])
def publish(body: PublishBody, admin=CA):
    return lms.admin_publish(admin, body.kind, body.item_id, body.published)

class QuizBody(BaseModel):
    lesson_id: str; questions: list; required: bool = False

@router.post("/quizzes", dependencies=[CA])
def create_quiz(body: QuizBody, admin=CA):
    return lms.admin_create_quiz(admin, **body.model_dump())

@router.get("/content/preview/{lesson_id}", dependencies=[CA])
def preview_lesson(lesson_id: str, as_tier: int = 1, admin=CA):
    fake = {"id": "admin-preview", "tier": as_tier, "language": "en",
            "billing_status": "active", "email": admin["email"]}
    return lms.get_lesson(fake, lesson_id)

@router.get("/content/analytics", dependencies=[CA])
def content_analytics(): return lms.learning_analytics()

# ============================================================ 8.7 AI/CHATBOT
class RAGBody(BaseModel):
    name: str; body: str; kind: str = "document"; min_tier: int = 1

@router.post("/rag/sources", dependencies=[SA])
def add_rag_source(body: RAGBody, admin=SA):
    sid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO rag_sources VALUES (?,?,?,?,1,?,?)",
                    (sid, body.name, body.kind, body.min_tier, body.body, D.now()))
    D.audit(admin["id"], "admin", "rag_source_added", target=sid)
    return {"id": sid}

@router.get("/rag/sources", dependencies=[SA])
def list_rag_sources():
    with D.db() as con:
        return [dict(r) for r in con.execute("SELECT id,name,kind,min_tier,enabled FROM rag_sources")]

class SettingBody(BaseModel):
    key: str; value: str

@router.post("/ai/settings", dependencies=[SA])
def update_ai_setting(body: SettingBody, admin=SA):
    with D.db() as con:
        con.execute("INSERT OR REPLACE INTO ai_settings VALUES (?,?)", (body.key, body.value))
    D.audit(admin["id"], "admin", "ai_setting_changed",
            detail={"key": body.key, "value": body.value})
    return {"ok": True}

@router.get("/ai/settings", dependencies=[SA])
def list_ai_settings():
    with D.db() as con:
        return {r["key"]: r["value"] for r in con.execute("SELECT * FROM ai_settings")}

class SimulateBody(BaseModel):
    message: str; tier: int

@router.post("/ai/simulate", dependencies=[SA])
def simulate_chat(body: SimulateBody, admin=SA):
    from chat_engine import simulate_as_tier
    D.audit(admin["id"], "admin", "chat_simulated", detail={"tier": body.tier})
    return simulate_as_tier(body.message, body.tier)

@router.get("/ai/flagged", dependencies=[SA])
def flagged_chats(limit: int = 50):
    with D.db() as con:
        flags = con.execute("""SELECT f.*, m.content user_msg,
                                      (SELECT content FROM messages WHERE conv_id=f.ref_id
                                       AND role='assistant' LIMIT 1) ai_reply
                               FROM moderation_flags f
                               LEFT JOIN messages m ON m.conv_id=f.ref_id AND m.role='user'
                               WHERE f.kind='chat_refusal' ORDER BY f.ts DESC LIMIT ?""",
                            (limit,)).fetchall()
    return [dict(r) for r in flags]

class ResolveFlag(BaseModel):
    resolution: str

@router.post("/ai/flagged/{flag_id}/resolve", dependencies=[SA])
def resolve_flag(flag_id: str, body: ResolveFlag, admin=SA):
    with D.db() as con:
        con.execute("UPDATE moderation_flags SET status='resolved', resolved_by=? WHERE id=?",
                    (admin["id"], flag_id))
    D.audit(admin["id"], "admin", "flag_resolved", target=flag_id,
            detail={"resolution": body.resolution})
    return {"ok": True}

# ============================================================ 8.8 INSIGHTS & SIGNALS
@router.post("/insights/generate/{kind}", dependencies=[SIGA])
def gen_insight(kind: str, admin=SIGA):
    if kind == "daily_news": return IS.generate_daily_news(admin["id"])
    if kind == "weekly_brief": return IS.generate_weekly_brief(admin["id"])
    if kind == "regime": return IS.generate_regime_commentary(admin["id"])
    raise HTTPException(400, "kind must be daily_news|weekly_brief|regime")

@router.get("/insights", dependencies=[SIGA])
def list_insights_admin():
    with D.db() as con:
        return [dict(r) for r in con.execute(
            "SELECT id,kind,title,status,min_tier,created_by,publish_at,published_at,"
            "expires_at,version FROM insights ORDER BY created DESC LIMIT 100")]

class InsightPublish(BaseModel):
    insight_id: str; status: str  # published|scheduled|draft|retracted

@router.post("/insights/publish", dependencies=[SIGA])
def publish_insight(body: InsightPublish, admin=SIGA):
    if body.status not in ("published", "scheduled", "draft", "retracted"):
        raise HTTPException(400, "Invalid status.")
    with D.db() as con:
        con.execute("UPDATE insights SET status=?, published_at=? WHERE id=?",
                    (body.status,
                     D.now() if body.status == "published" else None,
                     body.insight_id))
    D.audit(admin["id"], "admin", f"insight_{body.status}", target=body.insight_id)
    return {"ok": True}

@router.post("/signals/draft/{ticker}", dependencies=[SIGA])
def draft_signal(ticker: str, admin=SIGA):
    return IS.ai_draft_signal(admin["id"], ticker)

class SignalManualBody(BaseModel):
    asset: str; bias: str; signal_type: str; horizon: str
    assumptions: str; risk_context: str
    explanation: str = ""; invalidation: str = ""; expires_days: float = 14

@router.post("/signals/create", dependencies=[SIGA])
def create_signal_manual(body: SignalManualBody, admin=SIGA):
    return IS.create_signal(admin["id"], origin="human", **body.model_dump())

@router.post("/signals/{sid}/approve", dependencies=[SIGA])
def approve(sid: str, admin=SIGA): return IS.approve_signal(admin, sid)

class UpdateSignal(BaseModel):
    update_note: str; risk_context: str | None = None
    explanation: str | None = None; horizon: str | None = None

@router.post("/signals/{sid}/update", dependencies=[SIGA])
def update_sig(sid: str, body: UpdateSignal, admin=SIGA):
    return IS.update_signal(admin, sid, **body.model_dump())

class WithdrawSignal(BaseModel):
    reason: str

@router.post("/signals/{sid}/withdraw", dependencies=[SIGA])
def withdraw(sid: str, body: WithdrawSignal, admin=SIGA):
    return IS.withdraw_signal(admin, sid, body.reason)

@router.get("/signals", dependencies=[SIGA])
def list_signals_admin():
    with D.db() as con:
        rows = con.execute("""SELECT id,asset,bias,status,origin,approved_by,
                                     approved_at,published_at,expires_at,version,
                                     created_by,created
                              FROM trade_signals ORDER BY created DESC LIMIT 200""").fetchall()
    return [dict(r) for r in rows]

# ============================================================ 8.9 BROKER
@router.get("/broker/report", dependencies=[SA])
def broker_report(): return BA.referral_report()

class BrokerBody(BaseModel):
    name: str; redirect_template: str; referral_param: str = "ref"

@router.post("/broker/partners", dependencies=[SA])
def add_broker(body: BrokerBody, admin=SA):
    bid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO broker_partners VALUES (?,?,?,?,1,NULL)",
                    (bid, body.name, body.redirect_template, body.referral_param))
    D.audit(admin["id"], "admin", "broker_added", target=bid)
    return {"id": bid}

@router.get("/broker/partners", dependencies=[SA])
def list_brokers_admin():
    with D.db() as con:
        return [dict(r) for r in con.execute(
            "SELECT id,name,redirect_template,referral_param,enabled FROM broker_partners")]

# ============================================================ 8.10 RISK PROFILE
@router.get("/risk-profiles", dependencies=[SA])
def risk_distribution():
    with D.db() as con:
        dist = {r["risk_profile"]: r["n"] for r in con.execute(
            "SELECT risk_profile, COUNT(*) n FROM onboarding GROUP BY risk_profile").fetchall()}
        by_tier = [dict(r) for r in con.execute("""
            SELECT u.tier, o.risk_profile, COUNT(*) n FROM onboarding o
            JOIN users u ON u.id=o.user_id WHERE o.completed=1
            GROUP BY u.tier, o.risk_profile""").fetchall()]
        completion = {r["tier"]: r["rate"] for r in con.execute("""
            SELECT u.tier, ROUND(100.0*SUM(o.completed)/COUNT(*),1) rate
            FROM users u LEFT JOIN onboarding o ON o.user_id=u.id
            GROUP BY u.tier""").fetchall()}
    return {"distribution": dist, "by_tier": by_tier,
            "completion_rate_by_tier": completion,
            "note": "Admins cannot change individual risk buckets without logged justification."}

@router.get("/risk-profiles/audit", dependencies=[SA])
def risk_audit():
    with D.db() as con:
        return [dict(r) for r in con.execute("""
            SELECT * FROM audit_log WHERE action IN ('onboarding_reset','onboarding_completed')
            ORDER BY ts DESC LIMIT 200""").fetchall()]

# ============================================================ 8.11 JOBS / SCHEDULING
@router.get("/jobs", dependencies=[SA])
def list_jobs():
    with D.db() as con:
        return [dict(r) for r in con.execute("SELECT * FROM jobs").fetchall()]

class JobControl(BaseModel):
    job_id: str; enabled: bool

@router.post("/jobs/control", dependencies=[SA])
def control_job(body: JobControl, admin=SA):
    with D.db() as con:
        con.execute("UPDATE jobs SET enabled=? WHERE id=?", (int(body.enabled), body.job_id))
    D.audit(admin["id"], "admin", "job_toggled",
            detail={"job": body.job_id, "enabled": body.enabled})
    return {"ok": True}

@router.post("/jobs/{job_id}/trigger", dependencies=[SA])
def trigger_job(job_id: str, admin=SA):
    results = {
        "daily_news": IS.generate_daily_news,
        "weekly_brief": IS.generate_weekly_brief,
        "signal_expiry": IS.run_scheduler_tick,
        "insight_publisher": IS.run_scheduler_tick,
        "billing_cycle": T.apply_cycle_changes,
    }
    if job_id not in results:
        raise HTTPException(404, "Job not found.")
    out = results[job_id](admin["id"]) if job_id in ("daily_news", "weekly_brief") \
          else (results[job_id]() or {"ok": True})
    D.audit(admin["id"], "admin", "job_triggered", target=job_id)
    with D.db() as con:
        con.execute("UPDATE jobs SET last_run=?, last_status='ok' WHERE id=?",
                    (D.now(), job_id))
    return out

# ============================================================ 8.12 NOTIFICATIONS
class NotifRule(BaseModel):
    key: str; value: str

@router.post("/notifications/rules", dependencies=[SA])
def set_notif_rule(body: NotifRule, admin=SA):
    with D.db() as con:
        con.execute("INSERT OR REPLACE INTO ai_settings VALUES (?,?)",
                    (f"notif:{body.key}", body.value))
    D.audit(admin["id"], "admin", "notif_rule_set", detail=body.model_dump())
    return {"ok": True}

@router.get("/notifications/rules", dependencies=[SA])
def list_notif_rules():
    with D.db() as con:
        rows = con.execute("SELECT key,value FROM ai_settings WHERE key LIKE 'notif:%'").fetchall()
    return {r["key"].removeprefix("notif:"): r["value"] for r in rows}

# ============================================================ 8.13 AUDIT/COMPLIANCE
@router.get("/audit", dependencies=[SA])
def audit_log(action: str | None = None, actor: str | None = None,
              since_hours: float = 72, limit: int = 200):
    clause, params = ["ts>?"], [D.now() - since_hours * 3600]
    if action: clause.append("action=?"); params.append(action)
    if actor:  clause.append("actor=?"); params.append(actor)
    with D.db() as con:
        rows = con.execute(f"SELECT * FROM audit_log WHERE {' AND '.join(clause)} "
                           f"ORDER BY ts DESC LIMIT ?", (*params, limit)).fetchall()
    return [dict(r) for r in rows]

@router.get("/audit/export", dependencies=[SA])
def export_audit(since_hours: float = 720):
    rows = audit_log(since_hours=since_hours, limit=50000)
    out = io.StringIO()
    w = csv.DictWriter(out, fieldnames=["id","actor","actor_kind","action","target","detail","ts"])
    w.writeheader(); w.writerows(rows)
    from fastapi.responses import StreamingResponse
    return StreamingResponse(iter([out.getvalue()]),
                             media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=audit.csv"})

@router.get("/moderation/flags", dependencies=[SA])
def mod_flags(status: str = "open"):
    with D.db() as con:
        return [dict(r) for r in con.execute(
            "SELECT * FROM moderation_flags WHERE status=? ORDER BY ts DESC LIMIT 200",
            (status,)).fetchall()]

# ============================================================ 8.14 ANALYTICS
@router.get("/analytics", dependencies=[SA])
def analytics(since_hours: float = 720):
    cutoff = D.now() - since_hours * 3600
    with D.db() as con:
        growth = [dict(r) for r in con.execute(
            "SELECT tier, COUNT(*) n FROM users WHERE created>? GROUP BY tier", (cutoff,))]
        churn = con.execute(
            "SELECT COUNT(*) c FROM billing_events WHERE event='cancel' AND ts>?",
            (cutoff,)).fetchone()["c"]
        upgrades = [dict(r) for r in con.execute("""
            SELECT from_tier, to_tier, COUNT(*) n FROM billing_events
            WHERE event='paid' AND ts>? GROUP BY from_tier,to_tier""", (cutoff,)).fetchall()]
        signal_engagement = [dict(r) for r in con.execute("""
            SELECT s.asset, s.bias, COUNT(v.id) views, COUNT(i.id) broker_clicks
            FROM trade_signals s
            LEFT JOIN signal_views v ON v.signal_id=s.id
            LEFT JOIN trade_intents i ON i.signal_id=s.id
            GROUP BY s.id ORDER BY views DESC LIMIT 20""").fetchall()]
        funnel_rep = funnel.funnel_report(since_hours)
    return {"window_hours": since_hours,
            "user_growth_by_tier": growth, "cancellations": churn,
            "upgrade_paths": upgrades, "signal_engagement": signal_engagement,
            "learning": lms.learning_analytics(), "conversion_funnel": funnel_rep}

# ============================================================ 8.4 ADVISOR VIEW
@router.get("/advisor/users", dependencies=[ADV])
def advisor_users(admin=ADV):
    with D.db() as con:
        rows = con.execute(
            "SELECT id,email,tier FROM users WHERE advisor_id=?", (admin["id"],)).fetchall()
    return [dict(r) for r in rows]

@router.get("/advisor/summary/{uid}", dependencies=[ADV])
def get_summary(uid: str, admin=ADV):
    with D.db() as con:
        u = con.execute("SELECT advisor_id FROM users WHERE id=?", (uid,)).fetchone()
        if not u or u["advisor_id"] != admin["id"]:
            raise HTTPException(403, "Not assigned to you.")
    return BA.advisor_summary(uid)
