"""
AIMi — Learning & LMS (SOW Phase 3, complete)
=============================================
3.1 Course → module → lesson hierarchy; formats: video, pdf, image, quiz, text;
    metadata for tier, language, difficulty.
3.2 Learning library with filters and tier-aware locked indicators.
3.3 Content management (admin upload/replace/version) — production storage is
    GCS signed URLs per PGAGI architecture (see gcp.upload_url); URLs stored here.
3.4 Playback/consumption handled by frontend; consistent lesson payloads.
3.5 Progress tracking + resume position; course-level progress.
3.6 Tier gating enforced at backend (no bypass).
3.7 Quizzes: MCQ / true-false / short answer, instant feedback + explanations.
3.8 Lightweight gamification: badges, streaks, milestones (non-financial).
3.9 AIMi-powered recommendations from chat context + progress + profile.
3.10 Multilingual metadata + subtitles with default-language fallback.
3.11 Learning analytics events (completion, drop-off, quiz performance).
"""
from __future__ import annotations
import json, time
from fastapi import HTTPException

import db as D


# ------------------------------------------------------------ user library
def library(user: dict, topic: str | None = None, language: str | None = None,
            difficulty: str | None = None) -> list[dict]:
    with D.db() as con:
        rows = con.execute("SELECT * FROM courses WHERE published=1 ORDER BY position").fetchall()
        out = []
        for c in rows:
            if language and c["language"] != language: continue
            if difficulty and c["difficulty"] != difficulty: continue
            if topic and topic.lower() not in (c["title"] + c["description"]).lower(): continue
            lessons = con.execute("""SELECT l.* FROM lessons l JOIN modules m ON l.module_id=m.id
                                     WHERE m.course_id=? AND l.published=1
                                     ORDER BY m.position, l.position""", (c["id"],)).fetchall()
            total = len(lessons)
            done = con.execute("""SELECT COUNT(*) c FROM progress WHERE user_id=? AND completed=1
                                  AND lesson_id IN (SELECT l.id FROM lessons l JOIN modules m
                                  ON l.module_id=m.id WHERE m.course_id=?)""",
                               (user["id"], c["id"])).fetchone()["c"]
            locked = c["min_tier"] > user["tier"]
            out.append({**dict(c), "locked": locked,
                        "lock_message": f"Unlocks at Tier {c['min_tier']}" if locked else None,
                        "lessons_total": total, "lessons_done": done,
                        "progress_pct": round(done / total * 100) if total else 0})
    return out


def get_lesson(user: dict, lesson_id: str) -> dict:
    with D.db() as con:
        l = con.execute("SELECT * FROM lessons WHERE id=? AND published=1", (lesson_id,)).fetchone()
        if not l:
            raise HTTPException(404, "Lesson not found.")
        if l["min_tier"] > user["tier"]:   # backend enforcement — no bypass (3.6)
            raise HTTPException(403, f"This lesson unlocks at Tier {l['min_tier']}.")
        p = con.execute("SELECT * FROM progress WHERE user_id=? AND lesson_id=?",
                        (user["id"], lesson_id)).fetchone()
        quiz = con.execute("SELECT id, required FROM quizzes WHERE lesson_id=?",
                           (lesson_id,)).fetchone()
        subs = json.loads(l["subtitles"] or "[]")
        lang = user.get("language", "en")
        subtitle = next((s for s in subs if s.get("lang") == lang),
                        next((s for s in subs if s.get("lang") == "en"), None))  # fallback (3.10)
    return {**dict(l), "subtitle": subtitle,
            "resume_pos": p["resume_pos"] if p else 0,
            "completed": bool(p and p["completed"]),
            "quiz_id": quiz["id"] if quiz else None,
            "quiz_required": bool(quiz and quiz["required"])}


def update_progress(user: dict, lesson_id: str, resume_pos: float = 0,
                    completed: bool = False) -> dict:
    get_lesson(user, lesson_id)            # validates access
    with D.db() as con:
        con.execute("""INSERT INTO progress VALUES (?,?,?,?,?)
                       ON CONFLICT(user_id, lesson_id) DO UPDATE
                       SET resume_pos=?, completed=MAX(completed, ?), updated=?""",
                    (user["id"], lesson_id, int(completed), resume_pos, D.now(),
                     resume_pos, int(completed), D.now()))
    badges = _gamify(user["id"]) if completed else []
    if completed:
        D.audit(user["id"], "user", "lesson_completed", target=lesson_id)
    return {"saved": True, "new_badges": badges}


# ------------------------------------------------------------------ quizzes
def get_quiz(user: dict, quiz_id: str) -> dict:
    with D.db() as con:
        q = con.execute("SELECT * FROM quizzes WHERE id=?", (quiz_id,)).fetchone()
    if not q:
        raise HTTPException(404, "Quiz not found.")
    get_lesson(user, q["lesson_id"])       # tier check via lesson
    questions = json.loads(q["questions"])
    return {"id": q["id"], "lesson_id": q["lesson_id"],
            "questions": [{k: v for k, v in qq.items() if k not in ("answer", "explain")}
                          for qq in questions]}   # never leak answers


def submit_quiz(user: dict, quiz_id: str, answers: list) -> dict:
    with D.db() as con:
        q = con.execute("SELECT * FROM quizzes WHERE id=?", (quiz_id,)).fetchone()
    if not q:
        raise HTTPException(404, "Quiz not found.")
    questions = json.loads(q["questions"])
    feedback, correct = [], 0
    for i, qq in enumerate(questions):
        given = answers[i] if i < len(answers) else None
        if qq["type"] == "short":
            ok = str(given or "").strip().lower() == str(qq["answer"]).strip().lower()
        else:
            ok = given == qq["answer"]
        correct += ok
        feedback.append({"q": qq["q"], "correct": ok,
                         "explanation": qq.get("explain", "")})   # instant feedback (3.7)
    score = correct / max(len(questions), 1)
    with D.db() as con:
        con.execute("INSERT INTO quiz_results VALUES (?,?,?,?,?,?)",
                    (D.uid(), user["id"], quiz_id, score, json.dumps(answers), D.now()))
    if score == 1.0:
        _award(user["id"], "quiz_perfect", "Perfect quiz score")
    return {"score": round(score * 100), "feedback": feedback}


# -------------------------------------------------------- gamification (3.8)
def _award(user_id: str, kind: str, label: str) -> dict | None:
    with D.db() as con:
        if con.execute("SELECT 1 FROM badges WHERE user_id=? AND kind=?",
                       (user_id, kind)).fetchone():
            return None
        con.execute("INSERT INTO badges VALUES (?,?,?,?,?)",
                    (D.uid(), user_id, kind, label, D.now()))
    return {"kind": kind, "label": label}


def _gamify(user_id: str) -> list[dict]:
    earned = []
    with D.db() as con:
        done = con.execute("SELECT COUNT(*) c FROM progress WHERE user_id=? AND completed=1",
                           (user_id,)).fetchone()["c"]
        days = con.execute("""SELECT COUNT(DISTINCT DATE(updated,'unixepoch')) c FROM progress
                              WHERE user_id=? AND updated > ?""",
                           (user_id, D.now() - 7 * 86400)).fetchone()["c"]
    for threshold, kind, label in [(1, "first_lesson", "First lesson complete"),
                                   (5, "five_lessons", "5 lessons milestone"),
                                   (20, "twenty_lessons", "20 lessons milestone")]:
        if done >= threshold:
            b = _award(user_id, kind, label)
            if b: earned.append(b)
    if days >= 3:
        b = _award(user_id, "streak_3", "3-day learning streak")
        if b: earned.append(b)
    return earned


def my_badges(user_id: str) -> list[dict]:
    with D.db() as con:
        return [dict(r) for r in con.execute(
            "SELECT kind,label,ts FROM badges WHERE user_id=? ORDER BY ts DESC", (user_id,))]


# --------------------------------------------- AIMi-guided learning (3.9)
def recommend(user: dict, chat_context: str = "") -> list[dict]:
    items = library(user)
    unlocked = [c for c in items if not c["locked"]]
    # in-progress first, then keyword match against chat context, then untouched
    def rank(c):
        inprog = 0 < c["progress_pct"] < 100
        kw = sum(1 for w in chat_context.lower().split()
                 if len(w) > 4 and w in (c["title"] + c["description"]).lower())
        return (-int(inprog), -kw, c["progress_pct"])
    ranked = sorted(unlocked, key=rank)[:3]
    return [{"course_id": c["id"], "title": c["title"],
             "reason": "Continue where you left off" if 0 < c["progress_pct"] < 100
             else "Matches what you've been asking about" if chat_context else "A good next step",
             "deep_link": f"#learn/{c['id']}"} for c in ranked]


# -------------------------------------------------- admin content mgmt (3.3)
def admin_create_course(admin: dict, title, description, min_tier=1, language="en",
                        difficulty="beginner") -> dict:
    cid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO courses VALUES (?,?,?,?,?,?,0,0,?)",
                    (cid, title, description, min_tier, language, difficulty, D.now()))
    D.audit(admin["id"], "admin", "course_created", target=cid)
    return {"id": cid}


def admin_create_module(admin: dict, course_id, title, position=0) -> dict:
    mid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO modules VALUES (?,?,?,?)", (mid, course_id, title, position))
    return {"id": mid}


def admin_create_lesson(admin: dict, module_id, title, kind, content_url="", body="",
                        min_tier=1, language="en", duration_s=0, position=0,
                        subtitles=None) -> dict:
    if kind not in ("video", "pdf", "image", "quiz", "text"):
        raise HTTPException(400, "kind must be video|pdf|image|quiz|text")
    lid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO lessons VALUES (?,?,?,?,?,?,?,?,?,?,?,0,1)",
                    (lid, module_id, title, kind, content_url, body, duration_s,
                     min_tier, language, json.dumps(subtitles or []), position))
    D.audit(admin["id"], "admin", "lesson_created", target=lid, detail={"kind": kind})
    return {"id": lid}


def admin_publish(admin: dict, kind: str, item_id: str, published: bool):
    table = {"course": "courses", "lesson": "lessons"}.get(kind)
    if not table:
        raise HTTPException(400, "kind must be course|lesson")
    with D.db() as con:
        con.execute(f"UPDATE {table} SET published=? WHERE id=?", (int(published), item_id))
    D.audit(admin["id"], "admin", f"{kind}_{'published' if published else 'unpublished'}",
            target=item_id)
    return {"ok": True}


def admin_create_quiz(admin: dict, lesson_id: str, questions: list, required=False) -> dict:
    """Quiz template (per client query): [{q, type: mcq|tf|short, options, answer, explain}]"""
    for q in questions:
        if q.get("type") not in ("mcq", "tf", "short") or "answer" not in q:
            raise HTTPException(400, "Each question needs type (mcq|tf|short) and answer.")
    qid = D.uid()
    with D.db() as con:
        con.execute("INSERT INTO quizzes VALUES (?,?,?,?)",
                    (qid, lesson_id, json.dumps(questions), int(required)))
    D.audit(admin["id"], "admin", "quiz_created", target=qid)
    return {"id": qid}


def learning_analytics() -> dict:
    """(3.11 / 8.14) completion, drop-off, quiz performance."""
    with D.db() as con:
        total = con.execute("SELECT COUNT(*) c FROM progress").fetchone()["c"]
        done = con.execute("SELECT COUNT(*) c FROM progress WHERE completed=1").fetchone()["c"]
        quiz_avg = con.execute("SELECT AVG(score) a FROM quiz_results").fetchone()["a"]
        by_course = [dict(r) for r in con.execute("""
            SELECT c.title, COUNT(p.lesson_id) starts,
                   SUM(p.completed) completions
            FROM courses c
            JOIN modules m ON m.course_id=c.id
            JOIN lessons l ON l.module_id=m.id
            LEFT JOIN progress p ON p.lesson_id=l.id
            GROUP BY c.id""").fetchall()]
    return {"lessons_started": total, "lessons_completed": done,
            "completion_rate": round(done / total * 100, 1) if total else 0,
            "avg_quiz_score": round((quiz_avg or 0) * 100, 1), "by_course": by_course}


def seed_demo_content():
    """Seed a starter curriculum so MVP has no credibility gap (client query, Phase 3)."""
    with D.db() as con:
        if con.execute("SELECT 1 FROM courses").fetchone():
            return
    admin = {"id": "system"}
    c1 = admin_create_course(admin, "Money & Markets Foundations",
                             "Plain-English building blocks: what markets are, how money grows.", 1)
    c2 = admin_create_course(admin, "Investing Principles",
                             "Core principles: diversification, compounding, time in market.", 2)
    c3 = admin_create_course(admin, "Portfolio Thinking",
                             "Illustrative allocation logic, risk/return, macro effects.", 3)
    c4 = admin_create_course(admin, "Market Intelligence Masterclass",
                             "Regimes, volatility, factors and how professionals read markets.", 4)
    for cid, lessons in [
        (c1, [("What is a market?", "text", "A market is where buyers and sellers meet..."),
              ("Compounding — the eighth wonder", "text", "At 7% a year money doubles roughly every decade..."),
              ("Your freedom number", "text", "The amount at which work becomes optional...")]),
        (c2, [("Diversification explained", "text", "Don't put all eggs in one basket — formally..."),
              ("Dollar-cost averaging", "text", "Investing fixed amounts regularly reduces timing risk...")]),
        (c3, [("Risk and return trade-offs", "text", "Higher expected returns come with higher volatility..."),
              ("How macro moves markets", "text", "Rates, inflation and growth shape asset prices...")]),
        (c4, [("Reading market regimes", "text", "Risk-on vs risk-off conditions and what drives shifts..."),
              ("Volatility as information", "text", "What the VIX and realised vol tell professionals...")]),
    ]:
        m = admin_create_module(admin, cid["id"], "Module 1", 0)
        for i, (t, k, b) in enumerate(lessons):
            l = admin_create_lesson(admin, m["id"], t, k, body=b, position=i,
                                    subtitles=[{"lang": "en", "url": ""}])
            admin_publish(admin, "lesson", l["id"], True)
        admin_publish(admin, "course", cid["id"], True)
    # one demo quiz with the documented template
    with D.db() as con:
        lid = con.execute("SELECT id FROM lessons LIMIT 1").fetchone()["id"]
    admin_create_quiz(admin, lid, [
        {"q": "Compounding means…", "type": "mcq",
         "options": ["Earning returns on returns", "A type of broker fee", "A trading signal"],
         "answer": 0, "explain": "Reinvested returns generate their own returns over time."},
        {"q": "Markets only go up.", "type": "tf", "options": ["True", "False"],
         "answer": 1, "explain": "Markets move in both directions; volatility is normal."}])
