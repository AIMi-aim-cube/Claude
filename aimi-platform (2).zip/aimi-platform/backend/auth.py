"""
AIMi — Authentication & Sessions (SOW 1.2, 8.1, 8.2)
====================================================
Email/password with PBKDF2 hashing and opaque session tokens, plus optional
Firebase Authentication verification (the PGAGI production identity layer —
set GOOGLE_APPLICATION_CREDENTIALS / FIREBASE_PROJECT to enable; see gcp.py).
Separate admin authentication and strict RBAC dependencies (Phase 8).
"""
from __future__ import annotations
import hashlib, hmac, os, secrets, json
from fastapi import Header, HTTPException, Depends

import db as D

SESSION_TTL = 60 * 60 * 24 * 7  # 7 days
_PEPPER = os.getenv("AUTH_PEPPER", "aimi-dev-pepper")

ROLES = ["super_admin", "content_admin", "signals_admin", "advisor"]


def hash_pw(pw: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", (pw + _PEPPER).encode(), bytes.fromhex(salt), 200_000)
    return f"{salt}${digest.hex()}"


def verify_pw(pw: str, stored: str) -> bool:
    try:
        salt, digest = stored.split("$")
        cand = hashlib.pbkdf2_hmac("sha256", (pw + _PEPPER).encode(), bytes.fromhex(salt), 200_000)
        return hmac.compare_digest(cand.hex(), digest)
    except Exception:
        return False


# ----------------------------------------------------------------- sessions
def create_session(user_id: str, kind: str = "user") -> str:
    token = secrets.token_urlsafe(32)
    with D.db() as con:
        con.execute("INSERT INTO sessions VALUES (?,?,?,?,?)",
                    (token, user_id, kind, D.now(), D.now() + SESSION_TTL))
    return token


def destroy_session(token: str):
    with D.db() as con:
        con.execute("DELETE FROM sessions WHERE token=?", (token,))


def _session(token: str, kind: str):
    with D.db() as con:
        s = con.execute("SELECT * FROM sessions WHERE token=? AND kind=?", (token, kind)).fetchone()
        if not s or s["expires"] < D.now():
            return None
        return s


# -------------------------------------------------------------- user signup
def signup(email: str, password: str) -> dict:
    email = email.strip().lower()
    if "@" not in email or len(password) < 8:
        raise HTTPException(400, "Valid email and password of 8+ characters required.")
    with D.db() as con:
        if con.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
            raise HTTPException(409, "Account already exists.")
        user_id = D.uid()
        # Automatic Tier 1 (Foundation) assignment — SOW 1.4
        con.execute("INSERT INTO users (id,email,pw_hash,tier,created) VALUES (?,?,?,1,?)",
                    (user_id, email, hash_pw(password), D.now()))
    D.audit(user_id, "user", "signup", email)
    return {"user_id": user_id, "token": create_session(user_id), "tier": 1}


def login(email: str, password: str) -> dict:
    with D.db() as con:
        u = con.execute("SELECT * FROM users WHERE email=?", (email.strip().lower(),)).fetchone()
        if not u or not verify_pw(password, u["pw_hash"] or ""):
            D.audit(email, "user", "login_failed")
            raise HTTPException(401, "Invalid credentials.")
        if u["status"] != "active":
            raise HTTPException(403, f"Account is {u['status']}.")
        con.execute("UPDATE users SET last_login=? WHERE id=?", (D.now(), u["id"]))
    D.audit(u["id"], "user", "login")
    return {"user_id": u["id"], "token": create_session(u["id"]), "tier": u["tier"]}


def firebase_login(id_token: str) -> dict:
    """Production identity path (PGAGI architecture: Firebase Auth + Admin SDK)."""
    from gcp import verify_firebase_token
    info = verify_firebase_token(id_token)   # raises if invalid / not configured
    email = info["email"].lower()
    with D.db() as con:
        u = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if not u:
            user_id = D.uid()
            con.execute("INSERT INTO users (id,email,auth_provider,tier,created) "
                        "VALUES (?,?,?,1,?)", (user_id, email, "firebase", D.now()))
        else:
            user_id = u["id"]
        con.execute("UPDATE users SET last_login=? WHERE id=?", (D.now(), user_id))
    D.audit(user_id, "user", "login_firebase")
    return {"user_id": user_id, "token": create_session(user_id)}


# ----------------------------------------------------------- FastAPI deps
def current_user(authorization: str = Header("")) -> dict:
    token = authorization.removeprefix("Bearer ").strip()
    s = _session(token, "user")
    if not s:
        raise HTTPException(401, "Not authenticated.")
    with D.db() as con:
        u = con.execute("SELECT * FROM users WHERE id=?", (s["user_id"],)).fetchone()
    if not u or u["status"] != "active":
        raise HTTPException(403, "Account unavailable.")
    user = dict(u)
    user["token"] = token
    return user


def current_admin(authorization: str = Header("")) -> dict:
    token = authorization.removeprefix("Bearer ").strip()
    s = _session(token, "admin")
    if not s:
        raise HTTPException(401, "Admin authentication required.")
    with D.db() as con:
        a = con.execute("SELECT * FROM admins WHERE id=?", (s["user_id"],)).fetchone()
    if not a:
        raise HTTPException(401, "Admin not found.")
    return dict(a)


def require_role(*roles: str):
    """RBAC enforcement at API level (SOW 8.2). super_admin passes everything."""
    def dep(admin: dict = Depends(current_admin)) -> dict:
        if admin["role"] != "super_admin" and admin["role"] not in roles:
            D.audit(admin["id"], "admin", "rbac_denied", detail={"needed": roles})
            raise HTTPException(403, f"Requires role: {' or '.join(roles)}.")
        return admin
    return dep


def admin_login(email: str, password: str) -> dict:
    with D.db() as con:
        a = con.execute("SELECT * FROM admins WHERE email=?", (email.strip().lower(),)).fetchone()
        if not a or not verify_pw(password, a["pw_hash"]):
            D.audit(email, "admin", "admin_login_failed")
            raise HTTPException(401, "Invalid admin credentials.")
        con.execute("UPDATE admins SET last_login=? WHERE id=?", (D.now(), a["id"]))
    D.audit(a["id"], "admin", "admin_login")
    return {"admin_id": a["id"], "role": a["role"],
            "token": create_session(a["id"], kind="admin")}
