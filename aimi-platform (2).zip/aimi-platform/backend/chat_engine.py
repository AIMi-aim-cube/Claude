"""
AIMi — Chatbot Core (SOW Phase 2, complete)
===========================================
Tier-aware, compliant conversational engine:

  2.1  Governed AI framework (guide, never advisor; provider-agnostic LLM:
       Vertex AI Gemini per PGAGI architecture → OpenAI-compatible → local RAG)
  2.2  Intent classification + tier permission enforcement, no content leakage
  2.3  Tier-specific behaviour (1 Foundation → 5 Elite)
  2.4  Knowledge grounding on approved sources only (tier-filtered RAG)
  2.5  Conversation memory: session context + summarised long-term memory;
       explicit exclusions (assets owned, trades, balances never stored)
  2.6  Onboarding/risk profiling woven into chat
  2.7  Chat-guided navigation (deep links to Learn / Insights / Plans)
  2.8  Soft upgrade messaging with suppression/cooldown logic
  2.9  Safety, compliance & refusal engine (advice/execution/suitability)
  2.10 (UI in frontend/app.html)
  2.11 Full logging of prompts, refusals, boundaries; admin review hooks
"""
from __future__ import annotations
import json, os, re, time

import db as D
import tiers as T
from rag_pipeline import rag
from signals import DISCLAIMER

# ---------------------------------------------------------- intent detection
INTENTS = {
    "execution":  [r"\b(buy|sell|execute|place (an? )?order|short|long)\b.*\b(for me|now|my account)\b",
                   r"\b(can|will) you (buy|sell|trade|invest)\b"],
    "advice":     [r"\bshould i (buy|sell|invest|hold)\b", r"\bwhat (stock|coin|fund).{0,30}(buy|invest)\b",
                   r"\b(tell|recommend) me what to (buy|do with my money)\b", r"\bis \w+ a good (buy|investment) for me\b"],
    "signals":    [r"\bsignal", r"\btrade idea", r"\bsetups?\b", r"\bentry (point|level)\b"],
    "portfolio":  [r"\bportfolio\b", r"\ballocation\b", r"\bdiversif", r"\brebalanc"],
    "intelligence":[r"\bregime\b", r"\bvolatility\b", r"\bmacro\b", r"\bfactor", r"\bpattern"],
    "onboarding": [r"\b(risk profile|onboard|questionnaire)\b"],
    "navigation": [r"\b(lesson|course|learn|insight|brief|upgrade|plan|tier)\b"],
}

def classify_intent(text: str) -> str:
    t = text.lower()
    for intent, pats in INTENTS.items():
        if any(re.search(p, t) for p in pats):
            return intent
    return "education"


# ----------------------------------------------------- refusal engine (2.9)
REFUSALS = {
    "execution": ("I can't place, manage, or execute trades — AIMi never touches "
                  "execution, funds, or your accounts. When you decide to act, you do it "
                  "through your own broker. I can explain how order types work or what a "
                  "signal means, if that helps."),
    "advice": ("I can't tell you what *you* should buy or sell — that would be "
               "personalised financial advice, which AIMi doesn't provide. What I can do "
               "is explain how investors generally think about decisions like this: the "
               "trade-offs, the risks, and the concepts involved. Want me to walk through that?"),
}

def _blocked_terms() -> list[str]:
    with D.db() as con:
        r = con.execute("SELECT value FROM ai_settings WHERE key='blocked_terms'").fetchone()
    return json.loads(r["value"]) if r else []

def safety_check_output(text: str) -> str:
    """Output filter: strip prohibited promissory/instructional language (SOW 2.9, 4.4)."""
    for term in _blocked_terms():
        text = re.sub(re.escape(term), "[removed]", text, flags=re.I)
    text = re.sub(r"\byou should (buy|sell)\b", "some investors consider", text, flags=re.I)
    return text


# ----------------------------------------------------- tier behaviour (2.3)
TIER_PERSONAS = {
    1: "Explain in plain English with everyday analogies. Cover vocabulary and mental "
       "models (compounding, the freedom number). Do NOT discuss specific assets, "
       "tickers, allocations, or trades — gently redirect to concepts.",
    2: "Teach investing principles and walk through hypothetical scenarios. Reference "
       "earlier conversation. No buy/sell language, no personalised suggestions.",
    3: "You may discuss illustrative allocation logic, diversification intuition, "
       "risk/return trade-offs, and how macro events affect markets. Every example is "
       "educational and generic — never tied to the user's money.",
    4: "Provide market regime insights, volatility and factor explanations, and "
       "AI-detected patterns. Reference current insights and signals analytically. "
       "Frame everything as intelligence, never instruction.",
    5: "Support the advisory relationship: handle intake, recall prior sessions, and "
       "explain concepts the human advisor raised. Never introduce new recommendations — "
       "decisions belong to the human advisor.",
}

INTENT_MIN_TIER = {"portfolio": 3, "intelligence": 4, "signals": 4}


# ----------------------------------------------- soft upgrade nudges (2.8)
def _maybe_nudge(user: dict, intent: str) -> str | None:
    need = INTENT_MIN_TIER.get(intent)
    if not need or user["tier"] >= need:
        return None
    with D.db() as con:
        cd = float(con.execute("SELECT value FROM ai_settings WHERE key='upgrade_prompt_cooldown_s'")
                   .fetchone()["value"])
        last = con.execute("""SELECT MAX(ts) m FROM messages WHERE conv_id IN
                              (SELECT id FROM conversations WHERE user_id=?)
                              AND content LIKE '%[upgrade-hint]%'""", (user["id"],)).fetchone()["m"]
    if last and time.time() - last < cd:    # suppression logic — never over-prompt
        return None
    name = {3: "Portfolio", 4: "AIMi Pro"}.get(need, f"Tier {need}")
    return (f"\n\n[upgrade-hint] That topic sits in **Tier {need} ({name})**. No pressure — "
            f"you can compare what each tier includes any time on the Plans page. "
            f"Nothing here is required to invest.")


# --------------------------------------------------------- memory (2.5)
_FORBIDDEN_MEMORY = re.compile(r"\b(i (own|hold|bought|sold)|my (balance|account|position)s?|"
                               r"\$[\d,]+ (in|of) my)\b", re.I)

def _update_summary(conv_id: str, user_text: str, reply: str):
    """Summarised long-term memory; excludes holdings/trades/balances."""
    if _FORBIDDEN_MEMORY.search(user_text):
        return                      # explicit exclusion — regulated data never memorised
    with D.db() as con:
        row = con.execute("SELECT summary FROM conversations WHERE id=?", (conv_id,)).fetchone()
        summary = (row["summary"] + f" | asked about: {user_text[:80]}")[-1500:]
        con.execute("UPDATE conversations SET summary=?, updated=? WHERE id=?",
                    (summary, D.now(), conv_id))


# ------------------------------------------------------------ LLM providers
def _llm(system: str, history: list[dict], user_msg: str) -> str | None:
    # 1) Vertex AI Gemini (production path per PGAGI architecture)
    try:
        from gcp import gemini_chat
        out = gemini_chat(system, history, user_msg)
        if out:
            return out
    except Exception:
        pass
    # 2) Any OpenAI-compatible endpoint
    url = os.getenv("LLM_API_URL", "")
    if url:
        import requests
        msgs = [{"role": "system", "content": system}] + history[-8:] + \
               [{"role": "user", "content": user_msg}]
        try:
            r = requests.post(url.rstrip("/") + "/v1/chat/completions",
                              headers={"Authorization": f"Bearer {os.getenv('LLM_API_KEY','')}"},
                              json={"model": os.getenv("LLM_MODEL", "gpt-4o-mini"),
                                    "messages": msgs, "temperature": 0.4, "max_tokens": 500},
                              timeout=45)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception:
            return None
    return None


# ------------------------------------------------------------------- chat
def _daily_count(user_id: str) -> int:
    day = time.strftime("%Y-%m-%d")
    with D.db() as con:
        r = con.execute("SELECT count FROM chat_usage WHERE user_id=? AND day=?",
                        (user_id, day)).fetchone()
    return r["count"] if r else 0


def _bump_usage(user_id: str):
    day = time.strftime("%Y-%m-%d")
    with D.db() as con:
        con.execute("""INSERT INTO chat_usage VALUES (?,?,1)
                       ON CONFLICT(user_id, day) DO UPDATE SET count=count+1""", (user_id, day))


GREETING_RE = re.compile(r"^\s*(hi+|hello|hey|good (morning|evening|afternoon)|thanks?|ok)\W*$", re.I)


def chat(user: dict, message: str, conv_id: str | None = None) -> dict:
    feats = T.tier_features(user["tier"])

    # rate limit — pure greetings are NOT counted against the limit (per client query)
    counted = not GREETING_RE.match(message)
    if counted and _daily_count(user["id"]) >= feats.get("chat_limit_daily", 10):
        return {"conv_id": conv_id, "reply":
                f"You've reached today's chat limit for Tier {user['tier']}. It resets "
                f"tomorrow — or higher tiers include more daily conversations.",
                "intent": "rate_limited", "refused": False, "nudge": True}

    # conversation bootstrap
    with D.db() as con:
        if conv_id:
            conv = con.execute("SELECT * FROM conversations WHERE id=? AND user_id=?",
                               (conv_id, user["id"])).fetchone()
        else:
            conv = None
        if not conv:
            conv_id = D.uid()
            con.execute("INSERT INTO conversations VALUES (?,?,?,?,?, '')",
                        (conv_id, user["id"], message[:60], D.now(), D.now()))
            summary = ""
        else:
            summary = conv["summary"]
        history_rows = con.execute("SELECT role, content FROM messages WHERE conv_id=? "
                                   "ORDER BY ts DESC LIMIT 8", (conv_id,)).fetchall()
    history = [{"role": r["role"], "content": r["content"]} for r in reversed(history_rows)]
    if not feats.get("memory"):
        history, summary = [], ""           # Tier 1: no conversation memory

    intent = classify_intent(message)
    refused = False

    # ---- hard refusals: execution & personalised advice (all tiers) -------
    if intent in REFUSALS:
        reply, refused = REFUSALS[intent], True
        if intent == "execution":
            reply += "\n\n→ When you're ready to act, use the Trade via Broker button on a signal."
    # ---- tier boundary: restricted intelligence ----------------------------
    elif intent in INTENT_MIN_TIER and user["tier"] < INTENT_MIN_TIER[intent]:
        reply = (f"That's part of the {'signals' if intent=='signals' else intent} layer, "
                 f"which lives in Tier {INTENT_MIN_TIER[intent]}+. Here's what I can share at "
                 f"your tier: the general concept. ")
        reply += {"signals": "Signals are explained market intelligence — a directional view "
                             "with assumptions and risk context, never an instruction.",
                  "portfolio": "Portfolio thinking is about balancing risk across assets that "
                               "don't move together.",
                  "intelligence": "Market regimes describe whether conditions favour risk-taking "
                                  "or caution, based on volatility and trend data."}[intent]
        refused = True
    else:
        # ---- grounded generation (2.4): tier-filtered approved sources -----
        with D.db() as con:
            onb_row = con.execute("SELECT context, risk_profile FROM onboarding WHERE user_id=?",
                                  (user["id"],)).fetchone()
        context_info = (f"User context: {onb_row['context']}, risk profile: {onb_row['risk_profile']}."
                        if onb_row else "User has not completed onboarding.")

        rag_result = rag.answer(message, history=history)
        system = (f"You are AIMi, an AI investment guide built by Dr Ana Armstrong. You are an "
                  f"educator and decision-intelligence layer — never an advisor, broker or "
                  f"robo-trader. {TIER_PERSONAS[user['tier']]} {context_info} "
                  f"Long-term memory: {summary or 'none'}. "
                  f"Grounding context: {rag_result['answer'][:800]} "
                  f"Always include this stance: education not advice. Disclaimer: {DISCLAIMER}")
        reply = _llm(system, history, message) or rag_result["answer"]
        reply = safety_check_output(reply)
        # navigation hooks (2.7)
        if intent == "navigation":
            reply += "\n\n→ Quick links: [Learn](#learn) · [Insights](#insights) · [Plans](#plans)"

    nudge = _maybe_nudge(user, intent)
    if nudge:
        reply += nudge

    # ---- logging (2.11): prompts, responses, refusals, boundaries ----------
    with D.db() as con:
        con.execute("INSERT INTO messages VALUES (?,?,?,?,?,?,0,?,?)",
                    (D.uid(), conv_id, "user", message, intent, 0, user["tier"], D.now()))
        con.execute("INSERT INTO messages VALUES (?,?,?,?,?,?,0,?,?)",
                    (D.uid(), conv_id, "assistant", reply, intent, int(refused),
                     user["tier"], D.now()))
        if refused:
            con.execute("INSERT INTO moderation_flags (id,kind,ref_id,reason,ts) "
                        "VALUES (?,?,?,?,?)",
                        (D.uid(), "chat_refusal", conv_id, f"intent={intent}", D.now()))
    if refused:
        D.audit(user["id"], "user", "chat_refused", target=conv_id, detail={"intent": intent})
    if counted:
        _bump_usage(user["id"])
    if feats.get("memory"):
        _update_summary(conv_id, message, reply)

    return {"conv_id": conv_id, "reply": reply, "intent": intent,
            "refused": refused, "disclaimer": DISCLAIMER}


def simulate_as_tier(message: str, tier: int) -> dict:
    """Admin tool: test chatbot responses per tier (SOW 8.7)."""
    fake_user = {"id": "admin-simulator", "tier": tier, "email": "sim@aimi"}
    return chat(fake_user, message)
